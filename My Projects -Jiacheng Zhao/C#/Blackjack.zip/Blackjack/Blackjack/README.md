Strengths and Weaknesses of Stack
Strengths:

Efficiency: Operations like push and popping cards are very efficient, with a constant time complexity。

Simplicity: Stacks are simple to implement and use, making them ideal for scenarios where only last-in, first-out (LIFO) access is required.

Weaknesses:
Resource Consumption: While stacks themselves are not resource-intensive, the lack of random access can be a limitation. All elements must be accessed sequentially from the top, which can lead to increased time consumption if you need to access an element near the bottom.
Underflow and Overflow: Stacks can suffer from underflow (trying to pop from an empty stack) or overflow (exceeding the stack's capacity in limited memory scenarios), though overflow is less of a concern in dynamic or linked implementations.

To prevent the underflow, When the game start with less than 100 cards, the deck will be shuffled first, the game should be able to containue as long as the player have chips.

Performance Conditions:

Best Performance: Stacks perform best when operations are limited to the top of the collection, such as in undo mechanisms in software applications where only the most recent actions need to be reversed.
Worst Performance: Performance degrades when you need to access or remove elements that are not at the top of the stack, requiring removal of all elements above it first.
Real-World Application of Stack
Web Browsers' Back Button: The back button in web browsers uses a stack to keep track of visited URLs. Each new page visited is pushed onto the stack. When the back button is pressed, the current URL is popped from the stack, thus retrieving the last visited page.
Asymptotic Worst-Case Time and Space Complexity
Time Complexity: The worst-case time complexity of operations like push and pop in a stack is 
𝑂(1).
Space Complexity: The worst-case space complexity for a stack is 
O(n), where n is the number of elements in the stack. This is because each element must be stored individually.

issues encoutered:
1 set the maximum number of chips player can bet to the maximum.
2 draw a card when deck is empty.
3 situation of blackjack
4 bug: player can click unexpected buttons(e.g. before beting can hit to start the game with out beting)
