
namespace Blackjack
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Windows.Forms;

    public partial class Form1 : Form
    {
        private Stack<string> deck = new Stack<string>();
        private List<string> playerHand = new List<string>();
        private List<string> dealerHand = new List<string>();
        private List<PictureBox> playerCardImages = new List<PictureBox>();
        private List<PictureBox> dealerCardImages = new List<PictureBox>();
        private bool playerStood = false;
        private int playerChips = 1000;
        private int currentBet = 0;
        private bool isbet = false;
        // Buttons
        private Button btnHit = new Button();
        private Button btnStand = new Button();
        private Button btnNewGame = new Button();
        private Button btnAllIn = new Button();
        //Lables
        private Label lblPlayerScore = new Label();
        private Label lblDealerScore = new Label();
        private PictureBox picDeck = new PictureBox();
        private Label lblDeckCount = new Label();
        private PictureBox picChips = new PictureBox();
        private Label lblPlayerChips = new Label();
        private NumericUpDown numBetAmount = new NumericUpDown();
        private Button btnPlaceBet = new Button();
        private List<Keys> keySequence = new List<Keys>();
        private List<Keys> cheatCode = new List<Keys>
{
    Keys.Up,Keys.Up, Keys.Down,Keys.Down, Keys.Left,Keys.Right,Keys.Left,Keys.Right,Keys.B,Keys.A,Keys.B,Keys.A
};
        public Form1()
        {
            InitializeComponent();
            InitializeUI();
            InitializeDeck();
            DealInitialCards();
            this.KeyPreview = true;
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            keySequence.Add(e.KeyCode);  // Add the pressed key to the sequence

            // Remove extra keys if the sequence is longer than the cheat code
            if (keySequence.Count > cheatCode.Count)
            {
                keySequence.RemoveAt(0);
            }

            // Check if the current key sequence matches the cheat code
            if (keySequence.SequenceEqual(cheatCode))
            {
                ApplyCheatCode();
            }
        }
        private void ApplyCheatCode()
        {
            playerChips += 1000000;  // Add a million chips
            UpdateChipsCount();  // Update the UI to reflect the new chip count
            MessageBox.Show("Cheat activated! You've received 1,000,000 chips!");
        }


        private void InitializeUI()
        {
            // Form settings
            this.Text = "Blackjack Game";
            this.BackgroundImage = Image.FromFile(@"Images/greenfelt.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
            this.ClientSize = new Size(800, 600);

            // Player score label
            lblPlayerScore.ForeColor = Color.Blue;
            lblPlayerScore.Font = new Font("Arial", 12, FontStyle.Bold);
            lblPlayerScore.Location = new Point(100, 330); // Adjust as needed
            lblPlayerScore.AutoSize = true;
            this.Controls.Add(lblPlayerScore);

            // Dealer score label
            lblDealerScore.ForeColor = Color.Red;
            lblDealerScore.Font = new Font("Arial", 12, FontStyle.Bold);
            lblDealerScore.Location = new Point(100, 80); // Adjust as needed
            lblDealerScore.AutoSize = true;
            this.Controls.Add(lblDealerScore);

            // Hit button
            btnHit.Text = "Hit";
            btnHit.Location = new Point(50, 500);
            btnHit.Click += new EventHandler(this.btnHit_Click);
            this.Controls.Add(btnHit);

            // Stand button
            btnStand.Text = "Stand";
            btnStand.Location = new Point(150, 500);
            btnStand.Click += new EventHandler(this.btnStand_Click);
            this.Controls.Add(btnStand);

            // New game button
            
            btnNewGame.Text = "New Game";
            btnNewGame.Location = new Point(250, 500);
            btnNewGame.Click += new EventHandler(this.btnNewGame_Click);
            this.Controls.Add(btnNewGame);

            btnAllIn.Text = "All In";
            btnAllIn.Location = new Point(600, 560);  // Adjust the position as needed
            btnAllIn.Click += new EventHandler(this.btnAllIn_Click);
            this.Controls.Add(btnAllIn);

            // Setup the PictureBox for the deck
            picDeck.Image = Image.FromFile(@"Images/b1fv.png");  // Path to your upside-down card image
            picDeck.SizeMode = PictureBoxSizeMode.StretchImage;
            picDeck.Location = new Point(this.ClientSize.Width - 100, 10);  // Place it at the upper right corner
            picDeck.Size = new Size(48, 72);  // Smaller, zoomed version
            this.Controls.Add(picDeck);

            // Setup the Label for deck count
            lblDeckCount.ForeColor = Color.Black;
            lblDeckCount.Font = new Font("Arial", 12, FontStyle.Bold);
            lblDeckCount.Location = new Point(this.ClientSize.Width - 150, 100);  // Right next to the PictureBox
            lblDeckCount.AutoSize = true;
            this.Controls.Add(lblDeckCount);

            // Setup the PictureBox for the chips image
            picChips.Image = Image.FromFile(@"Images/chips.jpg");  // Ensure the image path is correct
            picChips.SizeMode = PictureBoxSizeMode.StretchImage;
            picChips.Location = new Point(550, 500);  // Place it in the upper left corner
            picChips.Size = new Size(48, 48);  // Adjust size as needed
            this.Controls.Add(picChips);

            // Player chips label
            lblPlayerChips.ForeColor = Color.Green;
            lblPlayerChips.Font = new Font("Arial", 12, FontStyle.Bold);
            lblPlayerChips.Location = new Point(600, 500); // Adjust as needed
            lblPlayerChips.AutoSize = true;
            this.Controls.Add(lblPlayerChips);

            // Bet amount numeric updown
            numBetAmount.Location = new Point(600, 530);
            numBetAmount.Size = new Size(120, 20);
            numBetAmount.Minimum = 1;
            numBetAmount.Maximum = playerChips; // Max bet is all player's chips
            numBetAmount.Value = 10; // Starting bet
            this.Controls.Add(numBetAmount);

            // Place bet button
            btnPlaceBet.Text = "Place Bet";
            btnPlaceBet.Location = new Point(730, 530);
            btnPlaceBet.Click += new EventHandler(this.btnPlaceBet_Click);
            this.Controls.Add(btnPlaceBet);

            UpdateChipsCount();  // Update the chips count initially

            UpdateDeckCount();  // Update the deck count initially
            btnHit.Enabled = false;
            btnStand.Enabled = false;
            btnNewGame.Enabled = false;
        }

        private void UpdateDeckCount()
        {
            lblDeckCount.Text = deck.Count.ToString()+" cards remain";  // Update the label with the count of cards in the deck
        }
        private void UpdateChipsCount()
        {
            lblPlayerChips.Text = $"Chips: {playerChips}";  // Update the label with the current chips count
        }

        private void InitializeDeck()
        {
            string[] suits = { "C", "D", "H", "S" };
            string[] values = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
            List<string> tempDeck = new List<string>();

            for (int i = 0; i < 4; i++)  // four decks
            {
                foreach (string suit in suits)
                {
                    foreach (string value in values)
                    {
                        tempDeck.Add(value + suit);
                    }
                }
            }

            ShuffleDeck(tempDeck);
        }

        private void ShuffleDeck(List<string> tempDeck)
        {
            Random rng = new Random();
            int n = tempDeck.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                string value = tempDeck[k];
                tempDeck[k] = tempDeck[n];
                tempDeck[n] = value;
            }

            foreach (string card in tempDeck)
            {
                deck.Push(card);
            }
        }

        private void DealInitialCards()
        {
            playerHand.Clear();
            dealerHand.Clear();
            playerHand.Add(deck.Pop());
            playerHand.Add(deck.Pop());
            dealerHand.Add(deck.Pop());
            dealerHand.Add(deck.Pop());

            
        }

        private void btnHit_Click(object sender, EventArgs e)
        {
            playerHand.Add(deck.Pop());
            UpdateGameUI();
            if (CalculateScore(playerHand) > 21)
            {
                MessageBox.Show("Bust! You've exceeded 21.");
                btnHit.Enabled = false;
                btnStand.Enabled = false;
                btnPlaceBet.Enabled = false;
                btnAllIn.Enabled = false;
                // Handle bust (e.g., disable buttons or end round)
            }
        }

        private void btnStand_Click(object sender, EventArgs e)
        {
            playerStood = true;
            btnHit.Enabled = false;
            btnStand.Enabled = false;
            btnPlaceBet.Enabled = false;
            btnAllIn.Enabled = false;
            DealerPlay();
            UpdateGameUI(); // This will now update the dealer's score to show the actual score
        }



        private void btnNewGame_Click(object sender, EventArgs e)
        {
            isbet = false;
            playerStood = false;  // Reset the flag indicating whether the player has stood
            playerHand.Clear();   // Clear player's hand
            dealerHand.Clear();   // Clear dealer's hand

            // Clear all PictureBoxes from the form and reset the lists
            foreach (PictureBox pic in playerCardImages)
            {
                this.Controls.Remove(pic);  // Remove PictureBox from the form
            }
            playerCardImages.Clear();  // Clear the list of PictureBoxes for the player

            foreach (PictureBox pic in dealerCardImages)
            {
                this.Controls.Remove(pic);  // Remove PictureBox from the form
            }
            dealerCardImages.Clear();  // Clear the list of PictureBoxes for the dealer
            if (deck.Count<=100)
            {
                InitializeDeck();  // Reinitialize the deck
            }
            DealInitialCards();  // Deal new initial cards
            ClearPictureBoxes();
            numBetAmount.Enabled = true;
            btnPlaceBet.Enabled = true;
            lblPlayerScore.Text = "Player Score: " ;
            lblDealerScore.Text = "Dealer Score: " ;
            btnPlaceBet.Enabled = true;
            btnAllIn.Enabled = true;

            btnNewGame.Enabled = false;
            btnHit.Enabled = false;
            btnStand.Enabled = false;

        }
        private void btnAllIn_Click(object sender, EventArgs e)
        {
            if (playerChips > 0)
            {
                currentBet = playerChips;  // Set the current bet to all of the player's chips
                playerChips = 0;  // Reduce player's chips to zero since they're all in
                DealInitialCards();
                UpdateGameUI();

                // Disable betting controls during the game
                btnAllIn.Enabled = false;
                numBetAmount.Enabled = false;
                btnPlaceBet.Enabled = false;
                isbet = true;
                btnHit.Enabled = true;
                btnStand.Enabled = true;
                btnNewGame.Enabled = true; // Update the UI for chip count
            }
            else
            {
                MessageBox.Show("You have no chips left to bet.", "Cannot Go All In", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnPlaceBet_Click(object sender, EventArgs e)
        {
            if (numBetAmount.Value > playerChips)
            {
                MessageBox.Show("You cannot bet more chips than you have.");
                return;
            }

            currentBet = (int)numBetAmount.Value;
            playerChips -= currentBet; // Deduct the bet from player's chips
            lblPlayerChips.Text = $"Chips: {playerChips}"; // Update chip count display

            DealInitialCards();
            UpdateGameUI();

            // Disable betting controls during the game
            numBetAmount.Enabled = false;
            btnPlaceBet.Enabled = false;
            btnAllIn.Enabled = false;
            isbet = true;
            btnHit.Enabled = true;
            btnStand.Enabled = true;
            btnNewGame.Enabled = true;
        }



        private void UpdateGameUI()
        {
                numBetAmount.Maximum = playerChips+currentBet;
                DisplayCards(playerHand, playerCardImages, 350, "player");
                DisplayCards(dealerHand, dealerCardImages, 100, "dealer");

                lblPlayerScore.Text = "Player Score: " + CalculateScore(playerHand).ToString();
                lblDealerScore.Text = "Dealer Score: " + CalculateScore(dealerHand).ToString();

                // Show the dealer's score as '?' until the player stands
                if (!playerStood)
                {
                    lblDealerScore.Text = "Dealer Score: ?";
                }
                UpdateDeckCount();  // Update the deck count initially
                UpdateChipsCount();
            
        }

        private void ClearPictureBoxes()
        {
            foreach (var pic in playerCardImages) this.Controls.Remove(pic);
            foreach (var pic in dealerCardImages) this.Controls.Remove(pic);
            playerCardImages.Clear();
            dealerCardImages.Clear();
        }


        private void DisplayCards(List<string> hand, List<PictureBox> images, int yPos, string owner)
        {
            int xOffset = 100;

            for (int i = 0; i < hand.Count; i++)
            {
                if (images.Count <= i)
                {
                    // Create a new PictureBox if it doesn't exist
                    PictureBox picBox = new PictureBox();
                    picBox.SizeMode = PictureBoxSizeMode.StretchImage;
                    picBox.Location = new Point(xOffset, yPos);
                    picBox.Size = new Size(72, 96);
                    this.Controls.Add(picBox);
                    images.Add(picBox);
                }

                // Decide whether to show the card face up or down
                if (owner == "dealer" && i == 1 && !playerStood)
                {
                    images[i].Image = Image.FromFile(@"Images/b1fv.png"); // Show back of the card
                }
                else
                {
                    images[i].Image = Image.FromFile(@"Images/" + hand[i] + ".PNG"); // Show face of the card
                }

                xOffset += 80;
            }
        }
        private void DealerPlay()
        {
            while (CalculateScore(dealerHand) < 17)
            {
                dealerHand.Add(deck.Pop());
            }
            UpdateGameUI();  // Ensure the UI is updated after dealer's turn
            if (CalculateScore(dealerHand) > 21)
            {
                MessageBox.Show("Dealer busts! You win!");
                playerChips+= 2*currentBet;
                currentBet = 0;
                // Handle dealer bust
            }
            else
            {
                // Compare scores and determine winner
                int player = CalculateScore(playerHand);
                int dealer = CalculateScore(dealerHand);

                if (playerHand.Count <= 2&&player > dealer && player ==21)
                {
                    MessageBox.Show("Black Jack! You Win with double chips!.");
                    playerChips+= 4*currentBet;
                    currentBet = 0;
                }
                else if (player > dealer)
                {
                    MessageBox.Show("You Win.");
                    playerChips+= 2*currentBet;
                    currentBet = 0;
                }
                else if (player == dealer) 
                {
                    MessageBox.Show("Draw.");
                    playerChips+= currentBet;
                    currentBet = 0;
                }
                else {
                    MessageBox.Show("You Lose.");
                    currentBet = 0;
                }


            }
        }
        private int CalculateScore(List<string> hand)
        {
            int score = 0;
            int aceCount = 0;

            foreach (var card in hand)
            {
                string value = card.Substring(0, card.Length - 1); // Extract card value (removing the suit)

                if (value == "J" || value == "Q" || value == "K")
                {
                    score += 10;
                }
                else if (value == "A")
                {
                    aceCount++;
                    score += 11; // Initially count all Aces as 11
                }
                else
                {
                    score += int.Parse(value); // Numeric cards add their own value
                }
            }

            // Adjust for Aces if score exceeds 21
            while (score > 21 && aceCount > 0)
            {
                score -= 10; // Change one Ace from 11 to 1
                aceCount--;
            }

            return score;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }




}
