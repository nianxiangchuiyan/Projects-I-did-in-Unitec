﻿namespace ASS1
{
    partial class Report2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.printPreviewControl1 = new System.Windows.Forms.PrintPreviewControl();
            this.btnPrintPreview = new System.Windows.Forms.Button();
            this.Return = new System.Windows.Forms.Button();
            this.Print = new System.Windows.Forms.Button();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.SuspendLayout();
            // 
            // btnNext
            // 
            this.btnNext.Image = global::ASS1.Properties.Resources._8541575_caret_square_down_icon1;
            this.btnNext.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNext.Location = new System.Drawing.Point(293, 21);
            this.btnNext.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(120, 121);
            this.btnNext.TabIndex = 11;
            this.btnNext.Text = "Next page";
            this.btnNext.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Image = global::ASS1.Properties.Resources._8665933_square_caret_up_icon1;
            this.btnPrevious.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrevious.Location = new System.Drawing.Point(151, 21);
            this.btnPrevious.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(120, 121);
            this.btnPrevious.TabIndex = 10;
            this.btnPrevious.Text = "Previous Page";
            this.btnPrevious.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // printPreviewControl1
            // 
            this.printPreviewControl1.Location = new System.Drawing.Point(21, 167);
            this.printPreviewControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.printPreviewControl1.Name = "printPreviewControl1";
            this.printPreviewControl1.Size = new System.Drawing.Size(655, 583);
            this.printPreviewControl1.TabIndex = 9;
            // 
            // btnPrintPreview
            // 
            this.btnPrintPreview.Image = global::ASS1.Properties.Resources.preview;
            this.btnPrintPreview.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrintPreview.Location = new System.Drawing.Point(14, 21);
            this.btnPrintPreview.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPrintPreview.Name = "btnPrintPreview";
            this.btnPrintPreview.Size = new System.Drawing.Size(120, 121);
            this.btnPrintPreview.TabIndex = 8;
            this.btnPrintPreview.Text = "Print Preview";
            this.btnPrintPreview.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPrintPreview.UseVisualStyleBackColor = true;
            this.btnPrintPreview.Click += new System.EventHandler(this.btnPrintPreview_Click);
            // 
            // Return
            // 
            this.Return.Image = global::ASS1.Properties.Resources.sign_out_option;
            this.Return.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Return.Location = new System.Drawing.Point(569, 21);
            this.Return.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Return.Name = "Return";
            this.Return.Size = new System.Drawing.Size(120, 121);
            this.Return.TabIndex = 7;
            this.Return.Text = "Return";
            this.Return.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Return.UseVisualStyleBackColor = true;
            this.Return.Click += new System.EventHandler(this.Return_Click);
            // 
            // Print
            // 
            this.Print.Image = global::ASS1.Properties.Resources.printer;
            this.Print.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Print.Location = new System.Drawing.Point(429, 21);
            this.Print.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Print.Name = "Print";
            this.Print.Size = new System.Drawing.Size(120, 121);
            this.Print.TabIndex = 6;
            this.Print.Text = "Print";
            this.Print.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Print.UseVisualStyleBackColor = true;
            this.Print.Click += new System.EventHandler(this.Print_Click);
            // 
            // printDocument
            // 
            this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintPage);
            // 
            // Report2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(73)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(701, 770);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.printPreviewControl1);
            this.Controls.Add(this.btnPrintPreview);
            this.Controls.Add(this.Return);
            this.Controls.Add(this.Print);
            this.Name = "Report2";
            this.Text = "Location Report";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.PrintPreviewControl printPreviewControl1;
        private System.Windows.Forms.Button btnPrintPreview;
        private System.Windows.Forms.Button Return;
        private System.Windows.Forms.Button Print;
        private System.Drawing.Printing.PrintDocument printDocument;
    }
}