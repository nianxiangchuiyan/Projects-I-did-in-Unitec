﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ASS1
{
    public partial class Locations : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        private CurrencyManager currencyManager;
        public Locations(DataModule dm, Mainform mnu)
        {

            InitializeComponent();
            DM = dm;
            frmMenu = mnu;
            Bindcontrols();
            AddLocationPanel.Location= new Point(250, 32);
            UpdateLocationPanel.Location = new Point(250, 32);
        }
        public static string CapitalizeFirstLetter(string input)
        {
            //Use to capitalize the first letter of the string
            if (string.IsNullOrEmpty(input))
                return input;

            return char.ToUpper(input[0]) + input.Substring(1).ToLower();
        }
        public void Bindcontrols() {
            try {
            txtLocationID.DataBindings.Add("Text", DM.dsKai, "Location.LocationID");
            txtLocationName.DataBindings.Add("Text", DM.dsKai, "Location.LocationName");
            txtAddress.DataBindings.Add("Text", DM.dsKai, "Location.Address");
            txtLocationID.Enabled = false;
            txtLocationName.Enabled = false;
            txtAddress.Enabled = false;
            lstLocation.DataSource = DM.dsKai;
            lstLocation.DisplayMember = "Location.LocationName";
            lstLocation.ValueMember = "Location.LocationID";
            currencyManager = ((CurrencyManager)this.BindingContext[DM.dsKai, "Location"]);


            }
            catch(Exception ex) {
            MessageBox.Show(ex.Message);
            }
        
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position > 0)
            {
                --currencyManager.Position;
            }
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position < currencyManager.Count - 1)
            {
                ++currencyManager.Position;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtAddAddress.Text = "";
            txtAddLocationName.Text = "";
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            btnAdd.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnReturn.Enabled = false;
            AddLocationPanel.Visible = true;
        }
            
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            txtUpdateAddress.Text = txtAddress.Text;
            txtUpdateLocationName.Text = txtLocationName.Text;

            btnUp.Enabled = false;
            btnDown.Enabled = false;
            btnAdd.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnReturn.Enabled = false;
            UpdateLocationPanel.Visible = true;

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataRowView drv = lstLocation.SelectedItem as DataRowView;

            bool yes = MessageBox.Show("Are you sure you want to delete this Location?", "Delete", MessageBoxButtons.YesNo) == DialogResult.Yes;

            if (yes&&!DM.IsLocationregistered(Convert.ToInt32( drv["LocationID"].ToString())))
            {
                drv.Delete();
                DM.UpdateLocation();
            }
            else if (yes&&DM.IsLocationregistered(Convert.ToInt32(drv["LocationID"].ToString())))
            { MessageBox.Show("This location is registered to an event, so it cannot be deleted"); }
        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            AddLocationPanel.Visible = false;
        }

        private void btnUpdateCancle_Click(object sender, EventArgs e)
        {
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            UpdateLocationPanel.Visible = false;
        }
        public static string CapitalizeWords(string input)
        {
            //Use to capitalize the first letter of each word in a string
            if (string.IsNullOrEmpty(input))
                return input;

            CultureInfo cultureInfo = CultureInfo.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            return textInfo.ToTitleCase(input.ToLower());
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtAddAddress.Text.Trim().Length>=1 && txtAddLocationName.Text.Trim().Length>=1)
            { 
         
            String locationName = CapitalizeWords(txtAddLocationName.Text.Trim());
                DataRow newRow = DM.dsKai.Tables["Location"].NewRow();
                newRow["LocationName"] = locationName;
                newRow["Address"] = txtAddAddress.Text.Trim();
                /*DM.ctnKai.Open();
                newRow["LocationID"] = DM.getFirstID(DM.dtLoactions);
                DM.ctnKai.Close();*/
                DM.dsKai.Tables["Location"].Rows.Add(newRow);
                DM.UpdateLocation();
                btnUp.Enabled = true;
                btnDown.Enabled = true;
                btnAdd.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
                btnReturn.Enabled = true;
                AddLocationPanel.Visible = false;
                MessageBox.Show("Location added successfully");
            }
            else if (txtAddAddress.Text.Trim().Length < 1)
            {
                MessageBox.Show("Please enter a valid address");
            }
            else if (txtAddLocationName.Text.Trim().Length < 1)
            {
                MessageBox.Show("Please enter a valid location name");
            }
            
        }

        private void btnUpdateSave_Click(object sender, EventArgs e)
        {
            if (txtUpdateAddress.Text.Trim().Length>=1 && txtUpdateLocationName.Text.Trim().Length>=1)
            {
                String locationName = CapitalizeWords(txtUpdateLocationName.Text.Trim());
                DataRow newRow = DM.dtLoactions.Rows[currencyManager.Position];
                newRow["LocationName"] = locationName;
                newRow["Address"] = txtUpdateAddress.Text.Trim();
                DM.UpdateLocation();


                btnUp.Enabled = true;
                btnDown.Enabled = true;
                btnAdd.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
                btnReturn.Enabled = true;
                UpdateLocationPanel.Visible = false;
            }
            else if (txtUpdateAddress.Text.Trim().Length < 1)
            {
                MessageBox.Show("Please enter a valid address");
            }
            else if (txtUpdateLocationName.Text.Trim().Length < 1)
            {
                MessageBox.Show("Please enter a valid location name");
            }

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
