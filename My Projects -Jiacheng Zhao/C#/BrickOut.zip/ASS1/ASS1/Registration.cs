﻿using ASS1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASS1
{
    public partial class Registration : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        // private CurrencyManager cmWhanau,cmRegistration, cmEvent,cmERW,cmERE;// not used any more



        //When selection changed in the event grid, update the registration grid to show the registrations for the selected event
        private void dgvEvents_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvEvents.CurrentRow != null)
            {
                int eventId = Convert.ToInt32(dgvEvents.CurrentRow.Cells["EventID"].Value);
                DM.eventRegisterView.RowFilter = $"EventID = {eventId}";
                dgvReg.DataSource = DM.eventRegisterView;
            }

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void UpdateRegistrationView(int eventId)
        {
            // Update the registration view to show the registrations for the selected event
            DM.eventRegisterView.RowFilter = $"EventID = {eventId}";
            dgvReg.DataSource = DM.eventRegisterView;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvReg.CurrentRow == null)
            {
                MessageBox.Show("Please select a registration entry to remove.");
                return;
            }

            // Get the selected registration ID
            int selectedRegistrationID = Convert.ToInt32(dgvReg.CurrentRow.Cells["RegistrationID"].Value);

            // Confirmation dialog
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to remove this registration entry?", "Confirm Removal", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                // Find and remove the row
                DataRow[] rows = DM.dtEventRegister.Select($"RegistrationID = {selectedRegistrationID}");
                if (rows.Length > 0)
                {
                    rows[0].Delete();
                    DM.UpdateEventRegister(); // Assuming this method commits the changes to the database

                    MessageBox.Show("Entry removed successfully.");

                    // Optionally refresh or update views if necessary
                    UpdateRegistrationView((int)dgvEvents.CurrentRow.Cells["EventID"].Value);
                }
                else
                {
                    MessageBox.Show("Error: Registration entry not found.");
                }
            }
        }


        //check if the whanau is already registered to the event
        private bool IsWhanauRegisteredToEvent(int whanauID, int eventID)
        {
            DM.eventRegisterView.RowFilter = $"WhanauID = {whanauID} AND EventID = {eventID}";
            bool isRegistered = DM.eventRegisterView.Count > 0;
            DM.eventRegisterView.RowFilter = ""; // Clear the filter after use
            return isRegistered;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Check if both a whānau and an event are selected
            if (dgvWhanau.CurrentRow == null || dgvEvents.CurrentRow == null)
            {
                MessageBox.Show("Please select both a whānau and an event.");
                return;
            }
            DataGridViewRow current = dgvEvents.CurrentRow;
            int selectedWhanauID = Convert.ToInt32(dgvWhanau.CurrentRow.Cells["WhanauID"].Value);
            int selectedEventID = Convert.ToInt32(dgvEvents.CurrentRow.Cells["EventID"].Value);

            Boolean selectedKaiP = cbGiveKai.Checked;
            // Check if already registered
            if (IsWhanauRegisteredToEvent(selectedWhanauID, selectedEventID))
            {
                current.Selected = true;
                MessageBox.Show("Whānau can only be registered to an event once.");
            }
            else
            {
                // Add registration
                DataRow newReg = DM.dtEventRegister.NewRow();
                newReg["WhanauID"] = selectedWhanauID;
                newReg["EventID"] = selectedEventID;
                newReg["KaiPreparation"] = selectedKaiP; 
                DM.dtEventRegister.Rows.Add(newReg);
                DM.UpdateEventRegister();
                current.Selected = true;
                MessageBox.Show("Entry added successfully.");
                
            }

        }

        public Registration(DataModule dm, Mainform mnu)
        {

            InitializeComponent();
            DM = dm;
            frmMenu = mnu;
            /*
            cmWhanau = (CurrencyManager)this.BindingContext[DM.dsKai, "Whanau"];
            cmRegistration = (CurrencyManager)this.BindingContext[DM.dsKai, "EventRegister"];
            cmEvent = (CurrencyManager)this.BindingContext[DM.dsKai, "Event"];
            cmERE = (CurrencyManager)this.BindingContext[DM.dsKai, "EventRegister.FK_EventRegister_Event"];
            cmERW = (CurrencyManager)this.BindingContext[DM.dsKai, "EventRegister.FK_EventRegister_Whanau"];*/
            BindControls();
        }

        public void BindControls() {
            //Set datasource for the DataGridViews
            dgvWhanau.DataSource = DM.whanauView;
            dgvEvents.DataSource = DM.eventsView;
            dgvReg.DataSource = DM.eventRegisterView;
            

        }
    }
}
