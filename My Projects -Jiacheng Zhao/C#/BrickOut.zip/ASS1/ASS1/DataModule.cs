﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASS1
{
    public partial class DataModule : Form
    {
        public DataTable dtKai;
        public DataTable dtLoactions;
        public DataTable dtWhanau;
        public DataTable dtEvents;
        public DataTable dtEventRegister;
        private DataView kaiView;
        public DataView loactionsView;
        public DataView whanauView;
        public DataView eventsView;
        public DataView eventRegisterView;


        public DataModule()
        {

            InitializeComponent();
            dsKai.EnforceConstraints = false;
            try
            {

                daKai.Fill(dsKai);
                dtKai = dsKai.Tables["Kai"];
                daLocations.Fill(dsKai);
                dtLoactions = dsKai.Tables["Location"];
                daWhanau.Fill(dsKai);
                dtWhanau =dsKai.Tables["Whanau"];
                daEvents.Fill(dsKai);
                dtEvents = dsKai.Tables["Event"];
                daEventRegister.Fill(dsKai);
                dtEventRegister = dsKai.Tables["EventRegister"];

                dsKai.EnforceConstraints = true;
            }
            catch (ConstraintException ex) { 
            
            }
            kaiView = new DataView(dtKai);
            kaiView.Sort = "KaiID";
            loactionsView = new DataView(dtLoactions);
            loactionsView.Sort = "LocationID";
            whanauView = new DataView(dtWhanau);
            whanauView.Sort = "WhanauID";
            eventsView = new DataView(dtEvents);
            eventsView.Sort = "EventID";
            eventRegisterView = new DataView(dtEventRegister);
            eventRegisterView.Sort = "RegistrationID";
        }
        public String GetEventName(int eventID) {
            try
            {
                return dtEvents.Rows[eventID - 1]["EventName"].ToString();
            } catch {
                return "";
            }
        }
        public String GetLocationName(int locationID) {
            try
            {
                for (int i = 0; i < dtLoactions.Rows.Count; i++)
                {
                    if (dtLoactions.Rows[i]["LocationID"].ToString() == locationID.ToString())
                        return dtLoactions.Rows[i]["LocationName"].ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }
        }
        public String GetLocationAddress(int locationID) {
            try
            {
                return dtLoactions.Rows[locationID - 1]["Address"].ToString();
            }
            catch
            {
                return "";
            }

        }
        public  int GetLocationID(String locationName) {
            try
            {
              
                for (int i = 0; i < dtLoactions.Rows.Count; i++)
                {

                    if (dtLoactions.Rows[i]["LocationName"].ToString() == locationName)
                    {
         
                        return Convert.ToInt32(dtLoactions.Rows[i]["LocationID"].ToString());
                    }
                }
                return -1;
            }
            catch {
            return -1;
            }
                
                }
        public int GetEventID(String eventName)
        {
            try
            {
                for (int i = 0; i < dtEvents.Rows.Count; i++)
                {
                    if (dtEvents.Rows[i]["EventName"].ToString() == eventName)
                        return Convert.ToInt32( dtEvents.Rows[i]["EventID"].ToString());
                }
                return -1;

            }
            catch
            {
                return -1;
            }
        }
        public string GetwhanauFirstName(int whanauID)
        {
            try
            {
                for (int i = 0; i < dtWhanau.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtWhanau.Rows[i]["WhanauID"].ToString()) == whanauID)
                        return dtWhanau.Rows[i]["FirstName"].ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }
        }
        public string GetwhanauLastName(int whanauID)
        {
            try {
                for (int i = 0; i < dtWhanau.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtWhanau.Rows[i]["WhanauID"].ToString()) == whanauID)
                        return dtWhanau.Rows[i]["LastName"].ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }
        }
        public string GetwhanauPhone(int whanauID)
        {
            try
            {
                for (int i = 0; i < dtWhanau.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtWhanau.Rows[i]["WhanauID"].ToString()) == whanauID)
                        return dtWhanau.Rows[i]["Phone"].ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }

        }


        public bool IsKaiRelation(int eventID)
        {
            for (int i = 0; i < dtKai.Rows.Count-1; i++)
            {
                if (Convert.ToInt32(dtKai.Rows[i]["EventID"].ToString()) == eventID)
                    return true;

            }
            return false;
        }
        public bool IsWhaRes(int WhanauID) { 
            for (int i = 0; i < dtEventRegister.Rows.Count; i++)
            {
                if (Convert.ToInt32(dtEventRegister.Rows[i]["WhanauID"].ToString()) == WhanauID)
                    return true;
            }
            return false;
        }
        public bool IsLocationregistered(int LocationID) {
            try
            {
                for (int i = 0; i < dtEvents.Rows.Count; i++)
                {
                    if (Convert.ToInt32(dtEvents.Rows[i]["LocationID"].ToString()) == LocationID)
                        return true;
                }
            }
            catch (System.FormatException) { }
            return false;
            }

public void UpdateKai()
        {
            daKai.Update(dtKai);
        }
        public void UpdateLocations()
        {
            daLocations.Update(dtLoactions);
        }

        public void UpdateWhanau()
        {
            daWhanau.Update(dtWhanau);
        }

        public void UpdateLocation() {
        daLocations.Update(dtLoactions);
        daLocations.AcceptChangesDuringUpdate = true;
        }
        public void UpdateEvents()
        {
            daEvents.Update(dtEvents);
        }


        public void UpdateEventRegister()
        {
            daEventRegister.Update(dtEventRegister);
        }

        private void daKai_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            // Include a variable and a command to retrieve
            // the identity value from the Access database.
            int newID = 0;
            OleDbCommand idCMD = new OleDbCommand("SELECT @@IDENTITY", ctnKai);
            if (e.StatementType == StatementType.Insert)
            {
                // Retrieve the identity value and
                // store it in the TreatmentID column.
                newID = (int)idCMD.ExecuteScalar();
                e.Row["KaiID"] = newID;
            }
        }
        // Tried use this method to get the next ID, thus make ID continue after deleting a row.But it only work in the program, restart or look in Access it will not work.
        // Because the ID  is always an AutoNumber column.
/*
        public int getFirstID(DataTable dt)
        {
            int newID = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i][0]) > newID)
                    newID=Convert.ToInt32(dt.Rows[i][0]);
            }
            return newID+1;
        }
        */
    }
}
