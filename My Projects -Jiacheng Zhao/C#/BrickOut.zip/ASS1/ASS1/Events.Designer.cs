﻿namespace ASS1
{
    partial class Events
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Events));
            this.txtEventLocation = new System.Windows.Forms.TextBox();
            this.txtEventName = new System.Windows.Forms.TextBox();
            this.txtEventID = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblEventName = new System.Windows.Forms.Label();
            this.lblEventID = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnUp = new System.Windows.Forms.Button();
            this.lstEvent = new System.Windows.Forms.ListBox();
            this.txtEventDate = new System.Windows.Forms.TextBox();
            this.lblEventDate = new System.Windows.Forms.Label();
            this.AddEventPanel = new System.Windows.Forms.Panel();
            this.dtpAddEventDate = new System.Windows.Forms.DateTimePicker();
            this.cbAddLocation = new System.Windows.Forms.ComboBox();
            this.LblAddEventDate = new System.Windows.Forms.Label();
            this.txtAddEventName = new System.Windows.Forms.TextBox();
            this.lblAddLocation = new System.Windows.Forms.Label();
            this.lblAddEventName = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.UpdateEventPanel = new System.Windows.Forms.Panel();
            this.dtpUpdateEventDate = new System.Windows.Forms.DateTimePicker();
            this.cbUpdateLocation = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUpdateEventName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnUpdateSave = new System.Windows.Forms.Button();
            this.btnUpdateCancle = new System.Windows.Forms.Button();
            this.AddEventPanel.SuspendLayout();
            this.UpdateEventPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtEventLocation
            // 
            this.txtEventLocation.Location = new System.Drawing.Point(380, 125);
            this.txtEventLocation.Margin = new System.Windows.Forms.Padding(2);
            this.txtEventLocation.Name = "txtEventLocation";
            this.txtEventLocation.Size = new System.Drawing.Size(160, 20);
            this.txtEventLocation.TabIndex = 39;
            // 
            // txtEventName
            // 
            this.txtEventName.Location = new System.Drawing.Point(380, 77);
            this.txtEventName.Margin = new System.Windows.Forms.Padding(2);
            this.txtEventName.Name = "txtEventName";
            this.txtEventName.Size = new System.Drawing.Size(160, 20);
            this.txtEventName.TabIndex = 38;
            // 
            // txtEventID
            // 
            this.txtEventID.Location = new System.Drawing.Point(380, 28);
            this.txtEventID.Margin = new System.Windows.Forms.Padding(2);
            this.txtEventID.Name = "txtEventID";
            this.txtEventID.Size = new System.Drawing.Size(27, 20);
            this.txtEventID.TabIndex = 37;
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblLocation.ForeColor = System.Drawing.Color.White;
            this.lblLocation.Location = new System.Drawing.Point(306, 125);
            this.lblLocation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(74, 20);
            this.lblLocation.TabIndex = 34;
            this.lblLocation.Text = "Location:";
            // 
            // lblEventName
            // 
            this.lblEventName.AutoSize = true;
            this.lblEventName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblEventName.ForeColor = System.Drawing.Color.White;
            this.lblEventName.Location = new System.Drawing.Point(281, 74);
            this.lblEventName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEventName.Name = "lblEventName";
            this.lblEventName.Size = new System.Drawing.Size(100, 20);
            this.lblEventName.TabIndex = 33;
            this.lblEventName.Text = "Event Name:";
            // 
            // lblEventID
            // 
            this.lblEventID.AutoSize = true;
            this.lblEventID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblEventID.ForeColor = System.Drawing.Color.White;
            this.lblEventID.Location = new System.Drawing.Point(306, 25);
            this.lblEventID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEventID.Name = "lblEventID";
            this.lblEventID.Size = new System.Drawing.Size(75, 20);
            this.lblEventID.TabIndex = 31;
            this.lblEventID.Text = "Event ID:";
            // 
            // btnReturn
            // 
            this.btnReturn.Image = global::ASS1.Properties.Resources.sign_out_option;
            this.btnReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnReturn.Location = new System.Drawing.Point(539, 281);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(2);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(90, 98);
            this.btnReturn.TabIndex = 30;
            this.btnReturn.Text = "RETURN";
            this.btnReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = global::ASS1.Properties.Resources.bin1;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDelete.Location = new System.Drawing.Point(434, 281);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 98);
            this.btnDelete.TabIndex = 29;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Image = global::ASS1.Properties.Resources.edit11;
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdate.Location = new System.Drawing.Point(331, 281);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 98);
            this.btnUpdate.TabIndex = 28;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::ASS1.Properties.Resources._134224_add_plus_new_icon;
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAdd.Location = new System.Drawing.Point(228, 281);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(90, 98);
            this.btnAdd.TabIndex = 27;
            this.btnAdd.Text = "ADD";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDown
            // 
            this.btnDown.Image = global::ASS1.Properties.Resources._8541575_caret_square_down_icon1;
            this.btnDown.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDown.Location = new System.Drawing.Point(110, 281);
            this.btnDown.Margin = new System.Windows.Forms.Padding(2);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(90, 98);
            this.btnDown.TabIndex = 26;
            this.btnDown.Text = "DOWN";
            this.btnDown.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnUp
            // 
            this.btnUp.Image = global::ASS1.Properties.Resources._8665933_square_caret_up_icon1;
            this.btnUp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUp.Location = new System.Drawing.Point(9, 281);
            this.btnUp.Margin = new System.Windows.Forms.Padding(2);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(90, 98);
            this.btnUp.TabIndex = 25;
            this.btnUp.Text = "UP";
            this.btnUp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // lstEvent
            // 
            this.lstEvent.FormattingEnabled = true;
            this.lstEvent.Location = new System.Drawing.Point(9, 9);
            this.lstEvent.Margin = new System.Windows.Forms.Padding(2);
            this.lstEvent.Name = "lstEvent";
            this.lstEvent.Size = new System.Drawing.Size(183, 251);
            this.lstEvent.TabIndex = 24;
            // 
            // txtEventDate
            // 
            this.txtEventDate.Location = new System.Drawing.Point(380, 176);
            this.txtEventDate.Margin = new System.Windows.Forms.Padding(2);
            this.txtEventDate.Name = "txtEventDate";
            this.txtEventDate.Size = new System.Drawing.Size(160, 20);
            this.txtEventDate.TabIndex = 43;
            // 
            // lblEventDate
            // 
            this.lblEventDate.AutoSize = true;
            this.lblEventDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblEventDate.ForeColor = System.Drawing.Color.White;
            this.lblEventDate.Location = new System.Drawing.Point(290, 173);
            this.lblEventDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEventDate.Name = "lblEventDate";
            this.lblEventDate.Size = new System.Drawing.Size(93, 20);
            this.lblEventDate.TabIndex = 44;
            this.lblEventDate.Text = "Event Date:";
            // 
            // AddEventPanel
            // 
            this.AddEventPanel.Controls.Add(this.dtpAddEventDate);
            this.AddEventPanel.Controls.Add(this.cbAddLocation);
            this.AddEventPanel.Controls.Add(this.LblAddEventDate);
            this.AddEventPanel.Controls.Add(this.txtAddEventName);
            this.AddEventPanel.Controls.Add(this.lblAddLocation);
            this.AddEventPanel.Controls.Add(this.lblAddEventName);
            this.AddEventPanel.Controls.Add(this.btnSave);
            this.AddEventPanel.Controls.Add(this.btnCancle);
            this.AddEventPanel.Location = new System.Drawing.Point(636, 10);
            this.AddEventPanel.Margin = new System.Windows.Forms.Padding(2);
            this.AddEventPanel.Name = "AddEventPanel";
            this.AddEventPanel.Size = new System.Drawing.Size(434, 353);
            this.AddEventPanel.TabIndex = 45;
            this.AddEventPanel.Visible = false;
            // 
            // dtpAddEventDate
            // 
            this.dtpAddEventDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAddEventDate.Location = new System.Drawing.Point(133, 165);
            this.dtpAddEventDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtpAddEventDate.Name = "dtpAddEventDate";
            this.dtpAddEventDate.Size = new System.Drawing.Size(151, 20);
            this.dtpAddEventDate.TabIndex = 53;
            // 
            // cbAddLocation
            // 
            this.cbAddLocation.FormattingEnabled = true;
            this.cbAddLocation.Location = new System.Drawing.Point(133, 114);
            this.cbAddLocation.Margin = new System.Windows.Forms.Padding(2);
            this.cbAddLocation.Name = "cbAddLocation";
            this.cbAddLocation.Size = new System.Drawing.Size(160, 21);
            this.cbAddLocation.TabIndex = 52;
            // 
            // LblAddEventDate
            // 
            this.LblAddEventDate.AutoSize = true;
            this.LblAddEventDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.LblAddEventDate.ForeColor = System.Drawing.Color.White;
            this.LblAddEventDate.Location = new System.Drawing.Point(43, 163);
            this.LblAddEventDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblAddEventDate.Name = "LblAddEventDate";
            this.LblAddEventDate.Size = new System.Drawing.Size(93, 20);
            this.LblAddEventDate.TabIndex = 50;
            this.LblAddEventDate.Text = "Event Date:";
            // 
            // txtAddEventName
            // 
            this.txtAddEventName.Location = new System.Drawing.Point(133, 67);
            this.txtAddEventName.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddEventName.Name = "txtAddEventName";
            this.txtAddEventName.Size = new System.Drawing.Size(160, 20);
            this.txtAddEventName.TabIndex = 47;
            // 
            // lblAddLocation
            // 
            this.lblAddLocation.AutoSize = true;
            this.lblAddLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddLocation.ForeColor = System.Drawing.Color.White;
            this.lblAddLocation.Location = new System.Drawing.Point(59, 115);
            this.lblAddLocation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddLocation.Name = "lblAddLocation";
            this.lblAddLocation.Size = new System.Drawing.Size(74, 20);
            this.lblAddLocation.TabIndex = 46;
            this.lblAddLocation.Text = "Location:";
            // 
            // lblAddEventName
            // 
            this.lblAddEventName.AutoSize = true;
            this.lblAddEventName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddEventName.ForeColor = System.Drawing.Color.White;
            this.lblAddEventName.Location = new System.Drawing.Point(34, 64);
            this.lblAddEventName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddEventName.Name = "lblAddEventName";
            this.lblAddEventName.Size = new System.Drawing.Size(100, 20);
            this.lblAddEventName.TabIndex = 45;
            this.lblAddEventName.Text = "Event Name:";
            // 
            // btnSave
            // 
            this.btnSave.Image = global::ASS1.Properties.Resources.diskette;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.Location = new System.Drawing.Point(224, 245);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 98);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.Image = global::ASS1.Properties.Resources.close__1_;
            this.btnCancle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancle.Location = new System.Drawing.Point(46, 245);
            this.btnCancle.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(90, 98);
            this.btnCancle.TabIndex = 30;
            this.btnCancle.Text = "Cancle";
            this.btnCancle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // UpdateEventPanel
            // 
            this.UpdateEventPanel.Controls.Add(this.dtpUpdateEventDate);
            this.UpdateEventPanel.Controls.Add(this.cbUpdateLocation);
            this.UpdateEventPanel.Controls.Add(this.label1);
            this.UpdateEventPanel.Controls.Add(this.txtUpdateEventName);
            this.UpdateEventPanel.Controls.Add(this.label2);
            this.UpdateEventPanel.Controls.Add(this.label3);
            this.UpdateEventPanel.Controls.Add(this.btnUpdateSave);
            this.UpdateEventPanel.Controls.Add(this.btnUpdateCancle);
            this.UpdateEventPanel.Location = new System.Drawing.Point(636, 375);
            this.UpdateEventPanel.Margin = new System.Windows.Forms.Padding(2);
            this.UpdateEventPanel.Name = "UpdateEventPanel";
            this.UpdateEventPanel.Size = new System.Drawing.Size(434, 353);
            this.UpdateEventPanel.TabIndex = 46;
            this.UpdateEventPanel.Visible = false;
            // 
            // dtpUpdateEventDate
            // 
            this.dtpUpdateEventDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpUpdateEventDate.Location = new System.Drawing.Point(133, 165);
            this.dtpUpdateEventDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtpUpdateEventDate.Name = "dtpUpdateEventDate";
            this.dtpUpdateEventDate.Size = new System.Drawing.Size(151, 20);
            this.dtpUpdateEventDate.TabIndex = 53;
            // 
            // cbUpdateLocation
            // 
            this.cbUpdateLocation.FormattingEnabled = true;
            this.cbUpdateLocation.Location = new System.Drawing.Point(133, 114);
            this.cbUpdateLocation.Margin = new System.Windows.Forms.Padding(2);
            this.cbUpdateLocation.Name = "cbUpdateLocation";
            this.cbUpdateLocation.Size = new System.Drawing.Size(160, 21);
            this.cbUpdateLocation.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(43, 163);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 50;
            this.label1.Text = "Event Date:";
            // 
            // txtUpdateEventName
            // 
            this.txtUpdateEventName.Location = new System.Drawing.Point(133, 67);
            this.txtUpdateEventName.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateEventName.Name = "txtUpdateEventName";
            this.txtUpdateEventName.Size = new System.Drawing.Size(160, 20);
            this.txtUpdateEventName.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(59, 115);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 20);
            this.label2.TabIndex = 46;
            this.label2.Text = "Location:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(34, 64);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 45;
            this.label3.Text = "Event Name:";
            // 
            // btnUpdateSave
            // 
            this.btnUpdateSave.Image = global::ASS1.Properties.Resources.diskette;
            this.btnUpdateSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdateSave.Location = new System.Drawing.Point(224, 240);
            this.btnUpdateSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateSave.Name = "btnUpdateSave";
            this.btnUpdateSave.Size = new System.Drawing.Size(90, 98);
            this.btnUpdateSave.TabIndex = 31;
            this.btnUpdateSave.Text = "Save";
            this.btnUpdateSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdateSave.UseVisualStyleBackColor = true;
            this.btnUpdateSave.Click += new System.EventHandler(this.btnUpdateSave_Click);
            // 
            // btnUpdateCancle
            // 
            this.btnUpdateCancle.Image = global::ASS1.Properties.Resources.close__1_;
            this.btnUpdateCancle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdateCancle.Location = new System.Drawing.Point(46, 240);
            this.btnUpdateCancle.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateCancle.Name = "btnUpdateCancle";
            this.btnUpdateCancle.Size = new System.Drawing.Size(90, 98);
            this.btnUpdateCancle.TabIndex = 30;
            this.btnUpdateCancle.Text = "Cancle";
            this.btnUpdateCancle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdateCancle.UseVisualStyleBackColor = true;
            this.btnUpdateCancle.Click += new System.EventHandler(this.btnUpdateCancle_Click);
            // 
            // Events
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(73)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(637, 388);
            this.Controls.Add(this.UpdateEventPanel);
            this.Controls.Add(this.AddEventPanel);
            this.Controls.Add(this.lblEventDate);
            this.Controls.Add(this.txtEventDate);
            this.Controls.Add(this.txtEventLocation);
            this.Controls.Add(this.txtEventName);
            this.Controls.Add(this.txtEventID);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.lblEventName);
            this.Controls.Add(this.lblEventID);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.lstEvent);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Events";
            this.Text = "Event Management";
            this.AddEventPanel.ResumeLayout(false);
            this.AddEventPanel.PerformLayout();
            this.UpdateEventPanel.ResumeLayout(false);
            this.UpdateEventPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtEventLocation;
        private System.Windows.Forms.TextBox txtEventName;
        private System.Windows.Forms.TextBox txtEventID;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblEventName;
        private System.Windows.Forms.Label lblEventID;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.ListBox lstEvent;
        private System.Windows.Forms.TextBox txtEventDate;
        private System.Windows.Forms.Label lblEventDate;
        private System.Windows.Forms.Panel AddEventPanel;
        private System.Windows.Forms.Label LblAddEventDate;
        private System.Windows.Forms.TextBox txtAddEventName;
        private System.Windows.Forms.Label lblAddLocation;
        private System.Windows.Forms.Label lblAddEventName;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.ComboBox cbAddLocation;
        private System.Windows.Forms.DateTimePicker dtpAddEventDate;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel UpdateEventPanel;
        private System.Windows.Forms.DateTimePicker dtpUpdateEventDate;
        private System.Windows.Forms.ComboBox cbUpdateLocation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUpdateEventName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnUpdateSave;
        private System.Windows.Forms.Button btnUpdateCancle;
    }
}