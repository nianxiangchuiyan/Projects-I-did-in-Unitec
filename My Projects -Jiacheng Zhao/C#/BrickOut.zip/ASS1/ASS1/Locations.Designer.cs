﻿namespace ASS1
{
    partial class Locations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Locations));
            this.txtLocationID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLocationName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lstLocation = new System.Windows.Forms.ListBox();
            this.AddLocationPanel = new System.Windows.Forms.Panel();
            this.txtAddLocationName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAddAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            this.UpdateLocationPanel = new System.Windows.Forms.Panel();
            this.txtUpdateLocationName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUpdateAddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnUpdateSave = new System.Windows.Forms.Button();
            this.btnUpdateCancle = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnUp = new System.Windows.Forms.Button();
            this.AddLocationPanel.SuspendLayout();
            this.UpdateLocationPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLocationID
            // 
            this.txtLocationID.Location = new System.Drawing.Point(395, 54);
            this.txtLocationID.Margin = new System.Windows.Forms.Padding(2);
            this.txtLocationID.Name = "txtLocationID";
            this.txtLocationID.Size = new System.Drawing.Size(60, 20);
            this.txtLocationID.TabIndex = 66;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(304, 52);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 20);
            this.label6.TabIndex = 65;
            this.label6.Text = "Location ID:";
            // 
            // txtLocationName
            // 
            this.txtLocationName.Location = new System.Drawing.Point(396, 105);
            this.txtLocationName.Margin = new System.Windows.Forms.Padding(2);
            this.txtLocationName.Name = "txtLocationName";
            this.txtLocationName.Size = new System.Drawing.Size(160, 20);
            this.txtLocationName.TabIndex = 62;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(279, 105);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label1.TabIndex = 61;
            this.label1.Text = "Location Name:";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(394, 156);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(161, 104);
            this.txtAddress.TabIndex = 64;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(323, 153);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 63;
            this.label4.Text = "Address:";
            // 
            // lstLocation
            // 
            this.lstLocation.FormattingEnabled = true;
            this.lstLocation.Location = new System.Drawing.Point(9, 9);
            this.lstLocation.Margin = new System.Windows.Forms.Padding(2);
            this.lstLocation.Name = "lstLocation";
            this.lstLocation.Size = new System.Drawing.Size(236, 264);
            this.lstLocation.TabIndex = 54;
            // 
            // AddLocationPanel
            // 
            this.AddLocationPanel.Controls.Add(this.txtAddLocationName);
            this.AddLocationPanel.Controls.Add(this.label2);
            this.AddLocationPanel.Controls.Add(this.txtAddAddress);
            this.AddLocationPanel.Controls.Add(this.label3);
            this.AddLocationPanel.Controls.Add(this.btnSave);
            this.AddLocationPanel.Controls.Add(this.btnCancle);
            this.AddLocationPanel.Location = new System.Drawing.Point(667, 26);
            this.AddLocationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.AddLocationPanel.Name = "AddLocationPanel";
            this.AddLocationPanel.Size = new System.Drawing.Size(358, 296);
            this.AddLocationPanel.TabIndex = 67;
            this.AddLocationPanel.Visible = false;
            // 
            // txtAddLocationName
            // 
            this.txtAddLocationName.Location = new System.Drawing.Point(144, 26);
            this.txtAddLocationName.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddLocationName.Name = "txtAddLocationName";
            this.txtAddLocationName.Size = new System.Drawing.Size(160, 20);
            this.txtAddLocationName.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(28, 24);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 65;
            this.label2.Text = "Location Name:";
            // 
            // txtAddAddress
            // 
            this.txtAddAddress.Location = new System.Drawing.Point(144, 58);
            this.txtAddAddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddAddress.Multiline = true;
            this.txtAddAddress.Name = "txtAddAddress";
            this.txtAddAddress.Size = new System.Drawing.Size(161, 104);
            this.txtAddAddress.TabIndex = 68;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(71, 55);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 67;
            this.label3.Text = "Address:";
            // 
            // btnSave
            // 
            this.btnSave.Image = global::ASS1.Properties.Resources.diskette;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.Location = new System.Drawing.Point(259, 183);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 98);
            this.btnSave.TabIndex = 49;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.Image = global::ASS1.Properties.Resources.close__1_;
            this.btnCancle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancle.Location = new System.Drawing.Point(75, 183);
            this.btnCancle.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(90, 98);
            this.btnCancle.TabIndex = 48;
            this.btnCancle.Text = "Cancle";
            this.btnCancle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // UpdateLocationPanel
            // 
            this.UpdateLocationPanel.Controls.Add(this.txtUpdateLocationName);
            this.UpdateLocationPanel.Controls.Add(this.label5);
            this.UpdateLocationPanel.Controls.Add(this.txtUpdateAddress);
            this.UpdateLocationPanel.Controls.Add(this.label7);
            this.UpdateLocationPanel.Controls.Add(this.btnUpdateSave);
            this.UpdateLocationPanel.Controls.Add(this.btnUpdateCancle);
            this.UpdateLocationPanel.Location = new System.Drawing.Point(667, 338);
            this.UpdateLocationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.UpdateLocationPanel.Name = "UpdateLocationPanel";
            this.UpdateLocationPanel.Size = new System.Drawing.Size(358, 296);
            this.UpdateLocationPanel.TabIndex = 68;
            this.UpdateLocationPanel.Visible = false;
            // 
            // txtUpdateLocationName
            // 
            this.txtUpdateLocationName.Location = new System.Drawing.Point(144, 26);
            this.txtUpdateLocationName.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateLocationName.Name = "txtUpdateLocationName";
            this.txtUpdateLocationName.Size = new System.Drawing.Size(160, 20);
            this.txtUpdateLocationName.TabIndex = 66;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(28, 24);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 20);
            this.label5.TabIndex = 65;
            this.label5.Text = "Location Name:";
            // 
            // txtUpdateAddress
            // 
            this.txtUpdateAddress.Location = new System.Drawing.Point(144, 58);
            this.txtUpdateAddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateAddress.Multiline = true;
            this.txtUpdateAddress.Name = "txtUpdateAddress";
            this.txtUpdateAddress.Size = new System.Drawing.Size(161, 104);
            this.txtUpdateAddress.TabIndex = 68;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(71, 55);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 20);
            this.label7.TabIndex = 67;
            this.label7.Text = "Address:";
            // 
            // btnUpdateSave
            // 
            this.btnUpdateSave.Image = global::ASS1.Properties.Resources.diskette;
            this.btnUpdateSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdateSave.Location = new System.Drawing.Point(259, 183);
            this.btnUpdateSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateSave.Name = "btnUpdateSave";
            this.btnUpdateSave.Size = new System.Drawing.Size(90, 98);
            this.btnUpdateSave.TabIndex = 49;
            this.btnUpdateSave.Text = "Save";
            this.btnUpdateSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdateSave.UseVisualStyleBackColor = true;
            this.btnUpdateSave.Click += new System.EventHandler(this.btnUpdateSave_Click);
            // 
            // btnUpdateCancle
            // 
            this.btnUpdateCancle.Image = global::ASS1.Properties.Resources.close__1_;
            this.btnUpdateCancle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdateCancle.Location = new System.Drawing.Point(75, 183);
            this.btnUpdateCancle.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateCancle.Name = "btnUpdateCancle";
            this.btnUpdateCancle.Size = new System.Drawing.Size(90, 98);
            this.btnUpdateCancle.TabIndex = 48;
            this.btnUpdateCancle.Text = "Cancle";
            this.btnUpdateCancle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdateCancle.UseVisualStyleBackColor = true;
            this.btnUpdateCancle.Click += new System.EventHandler(this.btnUpdateCancle_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Image = global::ASS1.Properties.Resources.sign_out_option;
            this.btnReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnReturn.Location = new System.Drawing.Point(540, 367);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(2);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(90, 98);
            this.btnReturn.TabIndex = 60;
            this.btnReturn.Text = "RETURN";
            this.btnReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = global::ASS1.Properties.Resources.bin1;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDelete.Location = new System.Drawing.Point(433, 367);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 98);
            this.btnDelete.TabIndex = 59;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Image = global::ASS1.Properties.Resources.edit11;
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdate.Location = new System.Drawing.Point(332, 367);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 98);
            this.btnUpdate.TabIndex = 58;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::ASS1.Properties.Resources._134224_add_plus_new_icon;
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAdd.Location = new System.Drawing.Point(230, 367);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(90, 98);
            this.btnAdd.TabIndex = 57;
            this.btnAdd.Text = "ADD";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDown
            // 
            this.btnDown.Image = global::ASS1.Properties.Resources._8541575_caret_square_down_icon1;
            this.btnDown.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDown.Location = new System.Drawing.Point(110, 367);
            this.btnDown.Margin = new System.Windows.Forms.Padding(2);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(90, 98);
            this.btnDown.TabIndex = 56;
            this.btnDown.Text = "DOWN";
            this.btnDown.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnUp
            // 
            this.btnUp.Image = global::ASS1.Properties.Resources._8665933_square_caret_up_icon1;
            this.btnUp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUp.Location = new System.Drawing.Point(8, 367);
            this.btnUp.Margin = new System.Windows.Forms.Padding(2);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(90, 98);
            this.btnUp.TabIndex = 55;
            this.btnUp.Text = "UP";
            this.btnUp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // Locations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(73)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(643, 476);
            this.Controls.Add(this.UpdateLocationPanel);
            this.Controls.Add(this.AddLocationPanel);
            this.Controls.Add(this.txtLocationID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtLocationName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.lstLocation);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Locations";
            this.Text = "Location Management";
            this.AddLocationPanel.ResumeLayout(false);
            this.AddLocationPanel.PerformLayout();
            this.UpdateLocationPanel.ResumeLayout(false);
            this.UpdateLocationPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLocationID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLocationName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.ListBox lstLocation;
        private System.Windows.Forms.Panel AddLocationPanel;
        private System.Windows.Forms.TextBox txtAddLocationName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAddAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.Panel UpdateLocationPanel;
        private System.Windows.Forms.TextBox txtUpdateLocationName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUpdateAddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnUpdateSave;
        private System.Windows.Forms.Button btnUpdateCancle;
    }
}