﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASS1
{
    public partial class Mainform : Form
    {
        private DataModule DM; // the reference to the form that holds the data components
        private Kai frmKai; // the reference to the Kai form
        private Events frmEvents; // the reference to the Events form
        private Registration frmReg; // the reference to the Registration form
        private Report frmReport; // the reference to the Report form
        private Whanau frmWhanau; // the reference to the Whanau form
        private Locations frmLoactions; // the reference to the Location form
        private Search frmSearch;
        private Report2 frmReport2;
        private void MainForm_Load(object sender, EventArgs e)
        {
            DM = new DataModule(); //create the data module and load the dataset
        }

        public Mainform()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {// Check if the user wants to exit

            //if (MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            Close(); // Close the form

        }

        private void btnLocation_Click(object sender, EventArgs e)
        {
            // Check if the form is already open
            if (frmLoactions == null)
            {
                // If not, create a new instance of the form
                frmLoactions = new Locations(DM, this);
            }
            // Show the form
            frmLoactions.ShowDialog();

        }

        private void btnWhanau_Click(object sender, EventArgs e)
        {
            if (frmWhanau == null)
            {
                frmWhanau = new Whanau(DM, this);
            }
            frmWhanau.ShowDialog();

        }

        private void btnReprot_Click(object sender, EventArgs e)
        {
            if (frmReport == null)
            {
                frmReport = new Report(DM, this);
            }
            frmReport.ShowDialog();

        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            if (frmReg == null)
            {
                frmReg = new Registration(DM, this);
            }
            frmReg.ShowDialog();

        }

        private void btnEvents_Click(object sender, EventArgs e)
        {
            if (frmEvents == null)
            {
                frmEvents = new Events(DM, this);
            }
            frmEvents.ShowDialog();

        }

        private void btnKai_Click(object sender, EventArgs e)
        {
            if (frmKai == null)
            {
                frmKai = new Kai(DM, this);
            }
            frmKai.ShowDialog();

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (frmSearch==null) {
                frmSearch = new Search(DM, this);
            }
            frmSearch.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (frmReport2 == null)
            {
                frmReport2 = new Report2 (DM, this);
            }
            frmReport2.ShowDialog();
        }
    }
}
