﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASS1
{
    public partial class Search : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        public Search(DataModule dm, Mainform mnu)
        {
            InitializeComponent();
            DM = dm;  // Store the DataModule reference
            frmMenu = mnu;  // Store the Mainform reference

        }

        //clear the search box at first time
        private void SearchBox_Click(object sender, EventArgs e)
        {
            if(SearchBox.Text == "Click here to search:")
            { SearchBox.Text =""; }
        }
        //Search the table
        private void SearchTable(DataTable table, string tableName, string query, string[] columns, StringBuilder results)
        {
            bool foundMatch = false;// flag to check if any match is found

            foreach (DataRow row in table.Rows)//for each row in the table
            {
                foreach (string column in columns)//for each column in the row
                {
                    if (row[column].ToString().ToLower().Contains(query))//if the column contains the query
                    {
                        foundMatch = true;
                        results.AppendLine($"--- {tableName} Match ---");
                        foreach (string col in columns)
                        {
                            results.AppendLine($"{col}: {row[col]}");
                        }
                        results.AppendLine("-----------------------");
                        results.AppendLine();
                        break;  // Exit inner loop once a match is found in this row
                    }
                }
            }

            if (!foundMatch)
            {
                results.AppendLine($"No matches found in {tableName}.");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string query = SearchBox.Text.Trim().ToLower();
            // Clear the results box before showing new results
            txtResult.Clear();

            if (string.IsNullOrEmpty(query))
            {
                MessageBox.Show("Please enter a search term.");
                return;
            }

            // Perform the search across different data tables
            StringBuilder results = new StringBuilder();
            try
            {
                // Search in Events
                SearchTable(DM.dtEvents, "Events", query, new string[] { "EventName", "LocationID","EventDate" }, results);

                // Search in Whanau
                SearchTable(DM.dtWhanau, "Whanau", query, new string[] { "FirstName", "LastName", "Phone","Email", "Address" }, results);

                // Search in Kai (Add more tables as needed)
                SearchTable(DM.dtKai, "Kai", query, new string[] { "KaiName", "PreparationMinutes", "ServeQuantity" }, results);
            }
            catch (Exception ex) { }
            // Display results in the results textbox
            txtResult.Text = results.Length > 0 ? results.ToString() : "No results found.";
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
