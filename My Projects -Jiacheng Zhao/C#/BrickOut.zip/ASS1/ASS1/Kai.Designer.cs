﻿namespace ASS1
{
    partial class Kai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kai));
            this.lstKai = new System.Windows.Forms.ListBox();
            this.lblKaiID = new System.Windows.Forms.Label();
            this.lblEvent = new System.Windows.Forms.Label();
            this.lblKaiName = new System.Windows.Forms.Label();
            this.lblPreparation = new System.Windows.Forms.Label();
            this.lblPreparationTime = new System.Windows.Forms.Label();
            this.lblServingQuantity = new System.Windows.Forms.Label();
            this.txtKaiID = new System.Windows.Forms.TextBox();
            this.txtKaiName = new System.Windows.Forms.TextBox();
            this.txtPreparation = new System.Windows.Forms.TextBox();
            this.txtEvent = new System.Windows.Forms.TextBox();
            this.AddKaiPanel = new System.Windows.Forms.Panel();
            this.cbAddEvent = new System.Windows.Forms.ComboBox();
            this.numAddServingQuantity = new System.Windows.Forms.NumericUpDown();
            this.numAddPreparationTime = new System.Windows.Forms.NumericUpDown();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            this.cbPreparation = new System.Windows.Forms.CheckBox();
            this.txtAddKaiName = new System.Windows.Forms.TextBox();
            this.lblAddServingQuantity = new System.Windows.Forms.Label();
            this.lblAddPreparationTime = new System.Windows.Forms.Label();
            this.lblAddPreparation = new System.Windows.Forms.Label();
            this.lblAddKaiName = new System.Windows.Forms.Label();
            this.lblAddEvent = new System.Windows.Forms.Label();
            this.btnUpdateSave = new System.Windows.Forms.Button();
            this.btnUpdateCancel = new System.Windows.Forms.Button();
            this.lblUpdateSavingQuantity = new System.Windows.Forms.Label();
            this.lblUpdatePreparationTime = new System.Windows.Forms.Label();
            this.lblUpdatePreparation = new System.Windows.Forms.Label();
            this.UpdateKaiPanel = new System.Windows.Forms.Panel();
            this.cbUpdateEvent = new System.Windows.Forms.ComboBox();
            this.numUpdateServingQuantity = new System.Windows.Forms.NumericUpDown();
            this.numUpdatePreparationTime = new System.Windows.Forms.NumericUpDown();
            this.txtUpdateKaiID = new System.Windows.Forms.TextBox();
            this.lblUpdateKaiID = new System.Windows.Forms.Label();
            this.cbUpdatePreparation = new System.Windows.Forms.CheckBox();
            this.txtUpdateKaiName = new System.Windows.Forms.TextBox();
            this.lblUpdateKaiName = new System.Windows.Forms.Label();
            this.lblUpdateEvent = new System.Windows.Forms.Label();
            this.numPreparationTime = new System.Windows.Forms.NumericUpDown();
            this.numServingQuantity = new System.Windows.Forms.NumericUpDown();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnUp = new System.Windows.Forms.Button();
            this.AddKaiPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAddServingQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAddPreparationTime)).BeginInit();
            this.UpdateKaiPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpdateServingQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpdatePreparationTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPreparationTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numServingQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // lstKai
            // 
            this.lstKai.FormattingEnabled = true;
            this.lstKai.ItemHeight = 16;
            this.lstKai.Location = new System.Drawing.Point(12, 12);
            this.lstKai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lstKai.Name = "lstKai";
            this.lstKai.Size = new System.Drawing.Size(243, 308);
            this.lstKai.TabIndex = 0;
            // 
            // lblKaiID
            // 
            this.lblKaiID.AutoSize = true;
            this.lblKaiID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblKaiID.ForeColor = System.Drawing.Color.White;
            this.lblKaiID.Location = new System.Drawing.Point(429, 78);
            this.lblKaiID.Name = "lblKaiID";
            this.lblKaiID.Size = new System.Drawing.Size(71, 25);
            this.lblKaiID.TabIndex = 7;
            this.lblKaiID.Text = "Kai ID:";
            // 
            // lblEvent
            // 
            this.lblEvent.AutoSize = true;
            this.lblEvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblEvent.ForeColor = System.Drawing.Color.White;
            this.lblEvent.Location = new System.Drawing.Point(432, 117);
            this.lblEvent.Name = "lblEvent";
            this.lblEvent.Size = new System.Drawing.Size(68, 25);
            this.lblEvent.TabIndex = 8;
            this.lblEvent.Text = "Event:";
            // 
            // lblKaiName
            // 
            this.lblKaiName.AutoSize = true;
            this.lblKaiName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblKaiName.ForeColor = System.Drawing.Color.White;
            this.lblKaiName.Location = new System.Drawing.Point(396, 158);
            this.lblKaiName.Name = "lblKaiName";
            this.lblKaiName.Size = new System.Drawing.Size(104, 25);
            this.lblKaiName.TabIndex = 9;
            this.lblKaiName.Text = "Kai Name:";
            // 
            // lblPreparation
            // 
            this.lblPreparation.AutoSize = true;
            this.lblPreparation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblPreparation.ForeColor = System.Drawing.Color.White;
            this.lblPreparation.Location = new System.Drawing.Point(377, 193);
            this.lblPreparation.Name = "lblPreparation";
            this.lblPreparation.Size = new System.Drawing.Size(123, 25);
            this.lblPreparation.TabIndex = 10;
            this.lblPreparation.Text = "Preparation?";
            // 
            // lblPreparationTime
            // 
            this.lblPreparationTime.AutoSize = true;
            this.lblPreparationTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblPreparationTime.ForeColor = System.Drawing.Color.White;
            this.lblPreparationTime.Location = new System.Drawing.Point(333, 228);
            this.lblPreparationTime.Name = "lblPreparationTime";
            this.lblPreparationTime.Size = new System.Drawing.Size(167, 25);
            this.lblPreparationTime.TabIndex = 11;
            this.lblPreparationTime.Text = "Preparation Time:";
            // 
            // lblServingQuantity
            // 
            this.lblServingQuantity.AutoSize = true;
            this.lblServingQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblServingQuantity.ForeColor = System.Drawing.Color.White;
            this.lblServingQuantity.Location = new System.Drawing.Point(343, 263);
            this.lblServingQuantity.Name = "lblServingQuantity";
            this.lblServingQuantity.Size = new System.Drawing.Size(158, 25);
            this.lblServingQuantity.TabIndex = 12;
            this.lblServingQuantity.Text = "ServingQuantity:";
            // 
            // txtKaiID
            // 
            this.txtKaiID.Location = new System.Drawing.Point(507, 78);
            this.txtKaiID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtKaiID.Name = "txtKaiID";
            this.txtKaiID.Size = new System.Drawing.Size(35, 22);
            this.txtKaiID.TabIndex = 13;
            // 
            // txtKaiName
            // 
            this.txtKaiName.Location = new System.Drawing.Point(507, 158);
            this.txtKaiName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtKaiName.Name = "txtKaiName";
            this.txtKaiName.Size = new System.Drawing.Size(212, 22);
            this.txtKaiName.TabIndex = 15;
            // 
            // txtPreparation
            // 
            this.txtPreparation.Location = new System.Drawing.Point(507, 193);
            this.txtPreparation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPreparation.Name = "txtPreparation";
            this.txtPreparation.Size = new System.Drawing.Size(49, 22);
            this.txtPreparation.TabIndex = 16;
            // 
            // txtEvent
            // 
            this.txtEvent.Location = new System.Drawing.Point(507, 117);
            this.txtEvent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEvent.Name = "txtEvent";
            this.txtEvent.Size = new System.Drawing.Size(212, 22);
            this.txtEvent.TabIndex = 18;
            this.txtEvent.TextChanged += new System.EventHandler(this.txtEvent_TextChanged);
            // 
            // AddKaiPanel
            // 
            this.AddKaiPanel.Controls.Add(this.cbAddEvent);
            this.AddKaiPanel.Controls.Add(this.numAddServingQuantity);
            this.AddKaiPanel.Controls.Add(this.numAddPreparationTime);
            this.AddKaiPanel.Controls.Add(this.btnSave);
            this.AddKaiPanel.Controls.Add(this.btnCancle);
            this.AddKaiPanel.Controls.Add(this.cbPreparation);
            this.AddKaiPanel.Controls.Add(this.txtAddKaiName);
            this.AddKaiPanel.Controls.Add(this.lblAddServingQuantity);
            this.AddKaiPanel.Controls.Add(this.lblAddPreparationTime);
            this.AddKaiPanel.Controls.Add(this.lblAddPreparation);
            this.AddKaiPanel.Controls.Add(this.lblAddKaiName);
            this.AddKaiPanel.Controls.Add(this.lblAddEvent);
            this.AddKaiPanel.Location = new System.Drawing.Point(885, 27);
            this.AddKaiPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddKaiPanel.Name = "AddKaiPanel";
            this.AddKaiPanel.Size = new System.Drawing.Size(579, 434);
            this.AddKaiPanel.TabIndex = 20;
            this.AddKaiPanel.Visible = false;
            // 
            // cbAddEvent
            // 
            this.cbAddEvent.FormattingEnabled = true;
            this.cbAddEvent.Location = new System.Drawing.Point(187, 123);
            this.cbAddEvent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbAddEvent.Name = "cbAddEvent";
            this.cbAddEvent.Size = new System.Drawing.Size(212, 24);
            this.cbAddEvent.TabIndex = 34;
            // 
            // numAddServingQuantity
            // 
            this.numAddServingQuantity.Location = new System.Drawing.Point(187, 238);
            this.numAddServingQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numAddServingQuantity.Name = "numAddServingQuantity";
            this.numAddServingQuantity.Size = new System.Drawing.Size(45, 22);
            this.numAddServingQuantity.TabIndex = 33;
            // 
            // numAddPreparationTime
            // 
            this.numAddPreparationTime.Location = new System.Drawing.Point(187, 202);
            this.numAddPreparationTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numAddPreparationTime.Name = "numAddPreparationTime";
            this.numAddPreparationTime.Size = new System.Drawing.Size(45, 22);
            this.numAddPreparationTime.TabIndex = 32;
            // 
            // btnSave
            // 
            this.btnSave.Image = global::ASS1.Properties.Resources.diskette;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSave.Location = new System.Drawing.Point(299, 309);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(120, 121);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.Image = global::ASS1.Properties.Resources.close__1_;
            this.btnCancle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCancle.Location = new System.Drawing.Point(80, 309);
            this.btnCancle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(120, 121);
            this.btnCancle.TabIndex = 30;
            this.btnCancle.Text = "Cancle";
            this.btnCancle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // cbPreparation
            // 
            this.cbPreparation.AutoSize = true;
            this.cbPreparation.Location = new System.Drawing.Point(187, 166);
            this.cbPreparation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbPreparation.Name = "cbPreparation";
            this.cbPreparation.Size = new System.Drawing.Size(18, 17);
            this.cbPreparation.TabIndex = 29;
            this.cbPreparation.UseVisualStyleBackColor = true;
            // 
            // txtAddKaiName
            // 
            this.txtAddKaiName.Location = new System.Drawing.Point(187, 86);
            this.txtAddKaiName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAddKaiName.Name = "txtAddKaiName";
            this.txtAddKaiName.Size = new System.Drawing.Size(212, 22);
            this.txtAddKaiName.TabIndex = 27;
            // 
            // lblAddServingQuantity
            // 
            this.lblAddServingQuantity.AutoSize = true;
            this.lblAddServingQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddServingQuantity.ForeColor = System.Drawing.Color.White;
            this.lblAddServingQuantity.Location = new System.Drawing.Point(23, 233);
            this.lblAddServingQuantity.Name = "lblAddServingQuantity";
            this.lblAddServingQuantity.Size = new System.Drawing.Size(158, 25);
            this.lblAddServingQuantity.TabIndex = 24;
            this.lblAddServingQuantity.Text = "ServingQuantity:";
            // 
            // lblAddPreparationTime
            // 
            this.lblAddPreparationTime.AutoSize = true;
            this.lblAddPreparationTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddPreparationTime.ForeColor = System.Drawing.Color.White;
            this.lblAddPreparationTime.Location = new System.Drawing.Point(13, 197);
            this.lblAddPreparationTime.Name = "lblAddPreparationTime";
            this.lblAddPreparationTime.Size = new System.Drawing.Size(167, 25);
            this.lblAddPreparationTime.TabIndex = 23;
            this.lblAddPreparationTime.Text = "Preparation Time:";
            // 
            // lblAddPreparation
            // 
            this.lblAddPreparation.AutoSize = true;
            this.lblAddPreparation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddPreparation.ForeColor = System.Drawing.Color.White;
            this.lblAddPreparation.Location = new System.Drawing.Point(57, 162);
            this.lblAddPreparation.Name = "lblAddPreparation";
            this.lblAddPreparation.Size = new System.Drawing.Size(123, 25);
            this.lblAddPreparation.TabIndex = 22;
            this.lblAddPreparation.Text = "Preparation?";
            // 
            // lblAddKaiName
            // 
            this.lblAddKaiName.AutoSize = true;
            this.lblAddKaiName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddKaiName.ForeColor = System.Drawing.Color.White;
            this.lblAddKaiName.Location = new System.Drawing.Point(77, 82);
            this.lblAddKaiName.Name = "lblAddKaiName";
            this.lblAddKaiName.Size = new System.Drawing.Size(104, 25);
            this.lblAddKaiName.TabIndex = 21;
            this.lblAddKaiName.Text = "Kai Name:";
            // 
            // lblAddEvent
            // 
            this.lblAddEvent.AutoSize = true;
            this.lblAddEvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblAddEvent.ForeColor = System.Drawing.Color.White;
            this.lblAddEvent.Location = new System.Drawing.Point(112, 123);
            this.lblAddEvent.Name = "lblAddEvent";
            this.lblAddEvent.Size = new System.Drawing.Size(68, 25);
            this.lblAddEvent.TabIndex = 20;
            this.lblAddEvent.Text = "Event:";
            // 
            // btnUpdateSave
            // 
            this.btnUpdateSave.Image = global::ASS1.Properties.Resources.diskette;
            this.btnUpdateSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdateSave.Location = new System.Drawing.Point(299, 309);
            this.btnUpdateSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdateSave.Name = "btnUpdateSave";
            this.btnUpdateSave.Size = new System.Drawing.Size(120, 121);
            this.btnUpdateSave.TabIndex = 31;
            this.btnUpdateSave.Text = "Save";
            this.btnUpdateSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdateSave.UseVisualStyleBackColor = true;
            this.btnUpdateSave.Click += new System.EventHandler(this.btnUpdateSave_Click);
            // 
            // btnUpdateCancel
            // 
            this.btnUpdateCancel.Image = global::ASS1.Properties.Resources.close__1_;
            this.btnUpdateCancel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdateCancel.Location = new System.Drawing.Point(80, 309);
            this.btnUpdateCancel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdateCancel.Name = "btnUpdateCancel";
            this.btnUpdateCancel.Size = new System.Drawing.Size(120, 121);
            this.btnUpdateCancel.TabIndex = 30;
            this.btnUpdateCancel.Text = "Cancle";
            this.btnUpdateCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdateCancel.UseVisualStyleBackColor = true;
            this.btnUpdateCancel.Click += new System.EventHandler(this.btnUpdateCancel_Click);
            // 
            // lblUpdateSavingQuantity
            // 
            this.lblUpdateSavingQuantity.AutoSize = true;
            this.lblUpdateSavingQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblUpdateSavingQuantity.ForeColor = System.Drawing.Color.White;
            this.lblUpdateSavingQuantity.Location = new System.Drawing.Point(23, 233);
            this.lblUpdateSavingQuantity.Name = "lblUpdateSavingQuantity";
            this.lblUpdateSavingQuantity.Size = new System.Drawing.Size(158, 25);
            this.lblUpdateSavingQuantity.TabIndex = 24;
            this.lblUpdateSavingQuantity.Text = "ServingQuantity:";
            // 
            // lblUpdatePreparationTime
            // 
            this.lblUpdatePreparationTime.AutoSize = true;
            this.lblUpdatePreparationTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblUpdatePreparationTime.ForeColor = System.Drawing.Color.White;
            this.lblUpdatePreparationTime.Location = new System.Drawing.Point(13, 197);
            this.lblUpdatePreparationTime.Name = "lblUpdatePreparationTime";
            this.lblUpdatePreparationTime.Size = new System.Drawing.Size(167, 25);
            this.lblUpdatePreparationTime.TabIndex = 23;
            this.lblUpdatePreparationTime.Text = "Preparation Time:";
            // 
            // lblUpdatePreparation
            // 
            this.lblUpdatePreparation.AutoSize = true;
            this.lblUpdatePreparation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblUpdatePreparation.ForeColor = System.Drawing.Color.White;
            this.lblUpdatePreparation.Location = new System.Drawing.Point(57, 162);
            this.lblUpdatePreparation.Name = "lblUpdatePreparation";
            this.lblUpdatePreparation.Size = new System.Drawing.Size(123, 25);
            this.lblUpdatePreparation.TabIndex = 22;
            this.lblUpdatePreparation.Text = "Preparation?";
            // 
            // UpdateKaiPanel
            // 
            this.UpdateKaiPanel.Controls.Add(this.cbUpdateEvent);
            this.UpdateKaiPanel.Controls.Add(this.numUpdateServingQuantity);
            this.UpdateKaiPanel.Controls.Add(this.numUpdatePreparationTime);
            this.UpdateKaiPanel.Controls.Add(this.txtUpdateKaiID);
            this.UpdateKaiPanel.Controls.Add(this.lblUpdateKaiID);
            this.UpdateKaiPanel.Controls.Add(this.btnUpdateSave);
            this.UpdateKaiPanel.Controls.Add(this.btnUpdateCancel);
            this.UpdateKaiPanel.Controls.Add(this.cbUpdatePreparation);
            this.UpdateKaiPanel.Controls.Add(this.txtUpdateKaiName);
            this.UpdateKaiPanel.Controls.Add(this.lblUpdateSavingQuantity);
            this.UpdateKaiPanel.Controls.Add(this.lblUpdatePreparationTime);
            this.UpdateKaiPanel.Controls.Add(this.lblUpdatePreparation);
            this.UpdateKaiPanel.Controls.Add(this.lblUpdateKaiName);
            this.UpdateKaiPanel.Controls.Add(this.lblUpdateEvent);
            this.UpdateKaiPanel.Location = new System.Drawing.Point(885, 468);
            this.UpdateKaiPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UpdateKaiPanel.Name = "UpdateKaiPanel";
            this.UpdateKaiPanel.Size = new System.Drawing.Size(579, 434);
            this.UpdateKaiPanel.TabIndex = 21;
            this.UpdateKaiPanel.Visible = false;
            // 
            // cbUpdateEvent
            // 
            this.cbUpdateEvent.FormattingEnabled = true;
            this.cbUpdateEvent.Location = new System.Drawing.Point(187, 124);
            this.cbUpdateEvent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbUpdateEvent.Name = "cbUpdateEvent";
            this.cbUpdateEvent.Size = new System.Drawing.Size(212, 24);
            this.cbUpdateEvent.TabIndex = 36;
            // 
            // numUpdateServingQuantity
            // 
            this.numUpdateServingQuantity.Location = new System.Drawing.Point(187, 238);
            this.numUpdateServingQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numUpdateServingQuantity.Name = "numUpdateServingQuantity";
            this.numUpdateServingQuantity.Size = new System.Drawing.Size(45, 22);
            this.numUpdateServingQuantity.TabIndex = 35;
            // 
            // numUpdatePreparationTime
            // 
            this.numUpdatePreparationTime.Location = new System.Drawing.Point(187, 199);
            this.numUpdatePreparationTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numUpdatePreparationTime.Name = "numUpdatePreparationTime";
            this.numUpdatePreparationTime.Size = new System.Drawing.Size(45, 22);
            this.numUpdatePreparationTime.TabIndex = 34;
            // 
            // txtUpdateKaiID
            // 
            this.txtUpdateKaiID.Enabled = false;
            this.txtUpdateKaiID.Location = new System.Drawing.Point(187, 50);
            this.txtUpdateKaiID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUpdateKaiID.Name = "txtUpdateKaiID";
            this.txtUpdateKaiID.Size = new System.Drawing.Size(35, 22);
            this.txtUpdateKaiID.TabIndex = 33;
            // 
            // lblUpdateKaiID
            // 
            this.lblUpdateKaiID.AutoSize = true;
            this.lblUpdateKaiID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblUpdateKaiID.ForeColor = System.Drawing.Color.White;
            this.lblUpdateKaiID.Location = new System.Drawing.Point(105, 50);
            this.lblUpdateKaiID.Name = "lblUpdateKaiID";
            this.lblUpdateKaiID.Size = new System.Drawing.Size(71, 25);
            this.lblUpdateKaiID.TabIndex = 32;
            this.lblUpdateKaiID.Text = "Kai ID:";
            // 
            // cbUpdatePreparation
            // 
            this.cbUpdatePreparation.AutoSize = true;
            this.cbUpdatePreparation.Location = new System.Drawing.Point(187, 166);
            this.cbUpdatePreparation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbUpdatePreparation.Name = "cbUpdatePreparation";
            this.cbUpdatePreparation.Size = new System.Drawing.Size(18, 17);
            this.cbUpdatePreparation.TabIndex = 29;
            this.cbUpdatePreparation.UseVisualStyleBackColor = true;
            // 
            // txtUpdateKaiName
            // 
            this.txtUpdateKaiName.Location = new System.Drawing.Point(187, 86);
            this.txtUpdateKaiName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUpdateKaiName.Name = "txtUpdateKaiName";
            this.txtUpdateKaiName.Size = new System.Drawing.Size(212, 22);
            this.txtUpdateKaiName.TabIndex = 27;
            // 
            // lblUpdateKaiName
            // 
            this.lblUpdateKaiName.AutoSize = true;
            this.lblUpdateKaiName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblUpdateKaiName.ForeColor = System.Drawing.Color.White;
            this.lblUpdateKaiName.Location = new System.Drawing.Point(77, 82);
            this.lblUpdateKaiName.Name = "lblUpdateKaiName";
            this.lblUpdateKaiName.Size = new System.Drawing.Size(104, 25);
            this.lblUpdateKaiName.TabIndex = 21;
            this.lblUpdateKaiName.Text = "Kai Name:";
            // 
            // lblUpdateEvent
            // 
            this.lblUpdateEvent.AutoSize = true;
            this.lblUpdateEvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblUpdateEvent.ForeColor = System.Drawing.Color.White;
            this.lblUpdateEvent.Location = new System.Drawing.Point(112, 123);
            this.lblUpdateEvent.Name = "lblUpdateEvent";
            this.lblUpdateEvent.Size = new System.Drawing.Size(68, 25);
            this.lblUpdateEvent.TabIndex = 20;
            this.lblUpdateEvent.Text = "Event:";
            // 
            // numPreparationTime
            // 
            this.numPreparationTime.Location = new System.Drawing.Point(507, 233);
            this.numPreparationTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numPreparationTime.Name = "numPreparationTime";
            this.numPreparationTime.Size = new System.Drawing.Size(49, 22);
            this.numPreparationTime.TabIndex = 22;
            // 
            // numServingQuantity
            // 
            this.numServingQuantity.Location = new System.Drawing.Point(507, 265);
            this.numServingQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numServingQuantity.Name = "numServingQuantity";
            this.numServingQuantity.Size = new System.Drawing.Size(49, 22);
            this.numServingQuantity.TabIndex = 23;
            // 
            // btnReturn
            // 
            this.btnReturn.Image = global::ASS1.Properties.Resources.sign_out_option;
            this.btnReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnReturn.Location = new System.Drawing.Point(719, 336);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 121);
            this.btnReturn.TabIndex = 6;
            this.btnReturn.Text = "RETURN";
            this.btnReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = global::ASS1.Properties.Resources.bin1;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDelete.Location = new System.Drawing.Point(567, 336);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(120, 121);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Image = global::ASS1.Properties.Resources.edit11;
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUpdate.Location = new System.Drawing.Point(441, 336);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(120, 121);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::ASS1.Properties.Resources._134224_add_plus_new_icon;
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAdd.Location = new System.Drawing.Point(315, 336);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(120, 121);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "ADD";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDown
            // 
            this.btnDown.Image = global::ASS1.Properties.Resources._8541575_caret_square_down_icon1;
            this.btnDown.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDown.Location = new System.Drawing.Point(139, 336);
            this.btnDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(120, 121);
            this.btnDown.TabIndex = 2;
            this.btnDown.Text = "DOWN";
            this.btnDown.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnUp
            // 
            this.btnUp.Image = global::ASS1.Properties.Resources._8665933_square_caret_up_icon1;
            this.btnUp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUp.Location = new System.Drawing.Point(12, 336);
            this.btnUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(120, 121);
            this.btnUp.TabIndex = 1;
            this.btnUp.Text = "UP";
            this.btnUp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // Kai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(73)))), ((int)(((byte)(41)))));
            this.ClientSize = new System.Drawing.Size(856, 476);
            this.Controls.Add(this.numServingQuantity);
            this.Controls.Add(this.numPreparationTime);
            this.Controls.Add(this.UpdateKaiPanel);
            this.Controls.Add(this.AddKaiPanel);
            this.Controls.Add(this.txtEvent);
            this.Controls.Add(this.txtPreparation);
            this.Controls.Add(this.txtKaiName);
            this.Controls.Add(this.txtKaiID);
            this.Controls.Add(this.lblServingQuantity);
            this.Controls.Add(this.lblPreparationTime);
            this.Controls.Add(this.lblPreparation);
            this.Controls.Add(this.lblKaiName);
            this.Controls.Add(this.lblEvent);
            this.Controls.Add(this.lblKaiID);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.lstKai);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Kai";
            this.Text = "kai Management";
            this.AddKaiPanel.ResumeLayout(false);
            this.AddKaiPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAddServingQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAddPreparationTime)).EndInit();
            this.UpdateKaiPanel.ResumeLayout(false);
            this.UpdateKaiPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpdateServingQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpdatePreparationTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPreparationTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numServingQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstKai;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblKaiID;
        private System.Windows.Forms.Label lblEvent;
        private System.Windows.Forms.Label lblKaiName;
        private System.Windows.Forms.Label lblPreparation;
        private System.Windows.Forms.Label lblPreparationTime;
        private System.Windows.Forms.Label lblServingQuantity;
        private System.Windows.Forms.TextBox txtKaiID;
        private System.Windows.Forms.TextBox txtKaiName;
        private System.Windows.Forms.TextBox txtPreparation;
        private System.Windows.Forms.TextBox txtEvent;
        private System.Windows.Forms.Panel AddKaiPanel;
        private System.Windows.Forms.CheckBox cbPreparation;
        private System.Windows.Forms.TextBox txtAddKaiName;
        private System.Windows.Forms.Label lblAddServingQuantity;
        private System.Windows.Forms.Label lblAddPreparationTime;
        private System.Windows.Forms.Label lblAddPreparation;
        private System.Windows.Forms.Label lblAddKaiName;
        private System.Windows.Forms.Label lblAddEvent;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.Button btnUpdateSave;
        private System.Windows.Forms.Button btnUpdateCancel;
        private System.Windows.Forms.Label lblUpdateSavingQuantity;
        private System.Windows.Forms.Label lblUpdatePreparationTime;
        private System.Windows.Forms.Label lblUpdatePreparation;
        private System.Windows.Forms.Panel UpdateKaiPanel;
        private System.Windows.Forms.CheckBox cbUpdatePreparation;
        private System.Windows.Forms.TextBox txtUpdateKaiName;
        private System.Windows.Forms.Label lblUpdateKaiName;
        private System.Windows.Forms.Label lblUpdateEvent;
        private System.Windows.Forms.TextBox txtUpdateKaiID;
        private System.Windows.Forms.Label lblUpdateKaiID;
        private System.Windows.Forms.NumericUpDown numPreparationTime;
        private System.Windows.Forms.NumericUpDown numServingQuantity;
        private System.Windows.Forms.ComboBox cbAddEvent;
        private System.Windows.Forms.NumericUpDown numAddServingQuantity;
        private System.Windows.Forms.NumericUpDown numAddPreparationTime;
        private System.Windows.Forms.ComboBox cbUpdateEvent;
        private System.Windows.Forms.NumericUpDown numUpdateServingQuantity;
        private System.Windows.Forms.NumericUpDown numUpdatePreparationTime;
    }
}