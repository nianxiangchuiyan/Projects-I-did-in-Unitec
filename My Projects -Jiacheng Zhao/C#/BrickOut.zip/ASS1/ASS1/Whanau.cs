﻿using ASS1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace ASS1
{
    public partial class Whanau : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        private CurrencyManager currencyManager;
        public Whanau(DataModule dm, Mainform mnu)
        {            
            InitializeComponent();
            DM = dm;
            frmMenu = mnu;
           BindControls();

    }

        //This method takes a string as an input and returns a string with the first letter capitalized
        public static string CapitalizeFirstLetter(string input)
        {
            //Check if the input string is null or empty
            if (string.IsNullOrEmpty(input))
                return input;

            //Capitalize the first letter of the input string and return the result
            return char.ToUpper(input[0]) + input.Substring(1).ToLower();
        }
        public void  BindControls() {
            //Set the data source for the text boxes to the data set and table
            txtWhaID.DataBindings.Add("Text", DM.dsKai, "Whanau.WhanauID");
            txtFName.DataBindings.Add("Text", DM.dsKai, "Whanau.FirstName");
            txtLName.DataBindings.Add("Text", DM.dsKai, "Whanau.LastName");
            txtPhone.DataBindings.Add("Text", DM.dsKai, "Whanau.Phone");
            txtEmail.DataBindings.Add("Text", DM.dsKai, "Whanau.Email");
            txtAddress.DataBindings.Add("Text", DM.dsKai, "Whanau.Address");
            //Disable the text boxes
            txtWhaID.Enabled = false;
            txtFName.Enabled = false;
            txtLName.Enabled = false;
            txtPhone.Enabled = false;
            txtEmail.Enabled = false;
            txtAddress.Enabled = false;
            //Set the data source for the list box to the data set and table
            lstWhanau.DataSource = DM.dsKai.Tables["Whanau"];
            lstWhanau.DisplayMember = "Whanau.FirstName";
            lstWhanau.ValueMember = "WhanauID";

            // This line of code adds a format event to the lstWhanau list view
            lstWhanau.Format += (s, e) =>
            {
               
                DataRowView drv = e.ListItem as DataRowView;
                if (drv != null)
                {
                    e.Value = $"{drv["FirstName"]} {drv["LastName"]}";
                }
            };

            // Set up a event handler for the lstWhanau SelectedIndexChanged event.
            lstWhanau.SelectedIndexChanged += (s, e) =>
            {
                if (lstWhanau.SelectedIndex >= 0)
                {
                    currencyManager.Position = lstWhanau.SelectedIndex;
                }
            };
            // Set the location of the AddWhaPanel and UpdateWhaPanel controls.
            AddWhaPanel.Location = new System.Drawing.Point(240, 11);
            UpdateWhaPanel.Location = new System.Drawing.Point(240, 11);

            // Create a CurrencyManager object for the Whanau property in the DataSource.
            currencyManager = ((CurrencyManager)this.BindingContext[DM.dsKai, "Whanau"]);
        }
        private void Whanau_Load(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
           if (currencyManager.Position > 0)
            {
                --currencyManager.Position;
            }

        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position < currencyManager.Count - 1)
            {
                ++currencyManager.Position;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //show the AddWhaPanel and hide the other controls
            lstWhanau.Visible = false;
            btnAdd.Enabled = false;
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
            btnReturn.Enabled = false;
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            AddWhaPanel.Visible = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //show the UpdateWhaPanel and hide the other controls
            txtUpdateAddress.Text = txtAddress.Text;
            txtUpdateEmail.Text = txtEmail.Text;
            txtUpdateFName.Text = txtFName.Text;
            txtUpdateLName.Text = txtLName.Text;
            txtUpdatePhone.Text = txtPhone.Text;
            lstWhanau.Visible = false;
            btnAdd.Enabled = false;
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
            btnReturn.Enabled = false;
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            UpdateWhaPanel.Visible = true;
        }
        //Delete button:
        private void btnDelete_Click(object sender, EventArgs e)
        {
           DataRowView drv = lstWhanau.SelectedItem as DataRowView;

            bool yes = MessageBox.Show("Are you sure you want to delete this Whanau?", "Delete", MessageBoxButtons.YesNo) == DialogResult.Yes;
            if (yes && !DM.IsKaiRelation(Convert.ToInt32(drv[0])))
            {

                drv.Delete();
                DM.UpdateEvents();
                MessageBox.Show("“Event deleted successfully”");
            }
            else if (DM.IsKaiRelation(Convert.ToInt32(drv[0])) && yes)
            {
                MessageBox.Show("You may only delete kai that have no event relation");
            }

        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            //Enable the controls in the Whanau form.
            lstWhanau.Visible = true;
            btnAdd.Enabled = true;
            btnDelete.Enabled = true;
            btnUpdate.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            AddWhaPanel.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstWhanau.Visible = true;
            btnAdd.Enabled = true;
            btnDelete.Enabled = true;
            btnUpdate.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            UpdateWhaPanel.Visible = false;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Check if the first name and last name are empty
            if (txtAddFName.Text.Trim().Length<1|| txtAddLName.Text.Trim().Length<1)
            {
                //Display a message box if the first name or last name is empty
                MessageBox.Show("First name and Last name can not be empty");
            }
            else if (txtAddEmail.Text== "" || !txtAddEmail.Text.Contains("@") || !txtAddEmail.Text.Contains("."))
            {
                //Display a message box if the email is not valid
                MessageBox.Show("Email is not valid");
            }
            else if (txtAddPhone.Text == "" || !txtAddPhone.Text.All(char.IsDigit))
            {
                //Display a message box if the phone number is not valid
                MessageBox.Show("Phone number is not valid");
            }
            else {
                //Capitalize the first letter of the first name and last name
                String Fname = CapitalizeFirstLetter(txtAddFName.Text.Trim());
                String Lname = CapitalizeFirstLetter(txtAddLName.Text.Trim());
                //Create a new row in the dtWhanau data table
                DataRow drv = DM.dtWhanau.NewRow();
                //Set the value of the first name, last name, email, phone, and address in the new row
                drv["FirstName"] = Fname;
                drv["LastName"] = Lname;
                drv["Email"] = txtAddEmail.Text.Trim();
                drv["Phone"] = txtAddPhone.Text.Trim();
                drv["Address"] = txtAddAddress.Text.Trim();
                //Add the new row to the dtWhanau data table
                DM.dtWhanau.Rows.Add(drv);
                //Update the dtWhanau data table
                DM.UpdateWhanau();
                //Display a message box to confirm the addition of the new customer
                MessageBox.Show("Whanau added successfully");
                //Set the list view to visible
                lstWhanau.Visible = true;
                //Enable the add, delete, update, and return buttons
                btnAdd.Enabled = true;
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;
                btnReturn.Enabled = true;
                //Enable the up and down buttons
                btnUp.Enabled = true;
                btnDown.Enabled = true;
                //Set the add customer panel to invisible
                AddWhaPanel.Visible = false;

            }
        }

        private void btnUpdateSave_Click(object sender, EventArgs e)
        {
            // Capitalize the first letters
            String Fname = CapitalizeFirstLetter(txtUpdateFName.Text.Trim());
            String Lname = CapitalizeFirstLetter(txtUpdateLName.Text.Trim());
            // Check if the first name and last name are empty
            if (txtUpdateFName.Text.Trim().Length < 1 || txtUpdateLName.Text.Trim().Length < 1)
            {
                MessageBox.Show("First name and Last name can not be empty");
            }

            // Check if the email is empty or not valid
            else if (txtUpdateEmail.Text == "" || !txtUpdateEmail.Text.Contains("@") || !txtUpdateEmail.Text.Contains("."))
            {
                MessageBox.Show("Email is not valid");
            }
            // Check if the phone number is empty or not valid
            else if (txtUpdatePhone.Text == "" || !txtUpdatePhone.Text.All(char.IsDigit))
            {
                MessageBox.Show("Phone number is not valid");
            }
            // If all checks pass, update the Whanau record
            else
            {


                // Get the current record from the Whanau data table
                DataRow drv = DM.dtWhanau.Rows[currencyManager.Position];
                // Update the first name, last name, email, phone, and address in the current record
                drv["FirstName"] = Fname;
                drv["LastName"] = Lname;
                drv["Email"] = txtUpdateEmail.Text.Trim();
                drv["Phone"] = txtUpdatePhone.Text.Trim();
                drv["Address"] = txtUpdateAddress.Text.Trim();
                // Update the Whanau record
                DM.UpdateWhanau();
                // Display a success message
                MessageBox.Show("Whanau updated successfully");
                // Enable the list view and buttons
                lstWhanau.Visible = true;
                btnDelete.Enabled = true;
                btnAdd.Enabled = true;
                btnUpdate.Enabled = true;
                btnReturn.Enabled = true;
                btnUp.Enabled = true;
                btnDown.Enabled = true;
                UpdateWhaPanel.Visible = false;

            }
        }
    }
}
