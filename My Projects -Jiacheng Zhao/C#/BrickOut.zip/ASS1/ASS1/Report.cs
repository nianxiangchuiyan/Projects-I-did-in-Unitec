﻿using ASS1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.Linq.Expressions;

namespace ASS1
{

    public partial class Report : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        private List<Dictionary<string, object>> events;
        private int currentPageIndex = 0;
        public Report(DataModule dm, Mainform mnu)
        {
            InitializeComponent();

            LoadData();
            DM = dm;
            frmMenu = mnu;
        }

        private void Return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Print_Click(object sender, EventArgs e)
        {
            events = FetchEvents();  // Fetch all events
           currentPageIndex = 0;
       // printPreviewDialog.ShowDialog();(NOT Working and causes the next line not working)
           printDocument.Print();

        }

        private void LoadData()
        {
            // This should be replaced with actual data fetching logic
            events = FetchEvents();
        }
        private List<Dictionary<string, object>> FetchEvents()
        {
            // Simulated data fetching

            {
                DM = new DataModule();
                var events = new List<Dictionary<string, object>>();
                if (DM != null && DM.dtEvents != null && DM.dtEvents.Rows.Count > 0)
                {
                    for (int i = 0; i < DM.dtEvents.Rows.Count; i++)
                    {
                        int LocationID = Convert.ToInt32(DM.dtEvents.Rows[i]["LocationID"]);
                        var eventDict= new Dictionary<string, object>
                    {
                        {"EventID", DM.dtEvents.Rows[i]["EventID"]},
                        {"EventName", DM.dtEvents.Rows[i]["EventName"]},
                        {"EventDate", DM.dtEvents.Rows[i]["EventDate"]},
                        {"Location", DM.GetLocationName(LocationID)},
                        {"Address", DM.GetLocationAddress(LocationID)},
                        {"Registrations", FetchRegistrationsForEvent(Convert.ToInt32(DM.dtEvents.Rows[i]["EventID"]))}
                    };
                        events.Add(eventDict);
                    }
                }
                    return events;
                };
        }

        private List<Dictionary<string, object>> FetchRegistrationsForEvent(int eventId)
        {
            // Simulated data fetching for registrations
            var registrations = new List<Dictionary<string, object>>();
        
            foreach (DataRow row in DM.dtEventRegister.Select($"EventID = {eventId}"))
            {
                int whanauID = Convert.ToInt32(row["WhanauID"]);
                registrations.Add(new Dictionary<string, object>
        {
            {"RegistrationID", row["RegistrationID"]},
            {"WhanauID", row["WhanauID"]},
            {"FirstName", DM.GetwhanauFirstName(whanauID)},
            {"LastName", DM.GetwhanauLastName(whanauID)},
            {"Phone", DM.GetwhanauPhone(whanauID)},
            {"KaiPreparation", row["KaiPreparation"]}
        });
            }

            return registrations;
        }

        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            // This method will be called for each page to be printed
            Graphics graphics = e.Graphics;
            Font titleFont = new Font("Arial", 10, FontStyle.Bold);
            Font bodyFont = new Font("Arial", 10);
            float lineHeight = bodyFont.GetHeight();
            float y = e.MarginBounds.Top;
            float x = e.MarginBounds.Left;

            if (currentPageIndex >= events.Count)
            {
                e.HasMorePages = false;
                return;
            }
            else { 
            e.HasMorePages = true;
            }

            var currentEvent = events[currentPageIndex];

            // Print Event Details with titles in bold and values in regular font
            graphics.DrawString("Event ID: ", titleFont, Brushes.Black, x, y);
            graphics.DrawString($"{currentEvent["EventID"]}", bodyFont, Brushes.Black, x + 70, y); // Adjust x position to align with data
            y += lineHeight;

            graphics.DrawString("Event Name: ", titleFont, Brushes.Black, x, y);
            graphics.DrawString($"{currentEvent["EventName"]}", bodyFont, Brushes.Black, x + 90, y);
            y += lineHeight;

            graphics.DrawString("Date: ", titleFont, Brushes.Black, x, y);
            graphics.DrawString($"{((DateTime)currentEvent["EventDate"]).ToShortDateString()}", bodyFont, Brushes.Black, x + 50, y);
            y += lineHeight;

            graphics.DrawString("Location: ", titleFont, Brushes.Black, x, y);
            graphics.DrawString($"{currentEvent["Location"]}", bodyFont, Brushes.Black, x + 80, y);
            y += lineHeight;

            graphics.DrawString("Address: ", titleFont, Brushes.Black, x, y);
            graphics.DrawString($"{currentEvent["Address"]}", bodyFont, Brushes.Black, x + 80, y);
            y += lineHeight * 1.5f;

            // Print Table Headers
            string[] headers = { "First Name", "Last Name", "Phone No.", "Helper" };
            float[] columnWidths = { 150, 150, 150, 80 }; // Total must be less than page width
            float currentX = x;

            // Draw headers
            for (int i = 0; i < headers.Length; i++)
            {
                graphics.DrawString(headers[i], titleFont, Brushes.Black, currentX, y);
                currentX += columnWidths[i];
            }
            y += lineHeight;

            // Draw attendees
            var registrations = (List<Dictionary<string, object>>)currentEvent["Registrations"];
            foreach (var reg in registrations)
            {
                currentX = x; // Reset to left margin for each attendee
                graphics.DrawString($"{reg["FirstName"]}", bodyFont, Brushes.Black, currentX, y);
                currentX += columnWidths[0];
                graphics.DrawString($"{reg["LastName"]}", bodyFont, Brushes.Black, currentX, y);
                currentX += columnWidths[1];
                graphics.DrawString($"{reg["Phone"]}", bodyFont, Brushes.Black, currentX, y);
                currentX += columnWidths[2];
                graphics.DrawString($"{((bool)reg["KaiPreparation"] ? "Yes" : "No")}", bodyFont, Brushes.Black, currentX, y);
                y += lineHeight; // Move to next line
            }

            currentPageIndex++;  // Prepare for next event
            e.HasMorePages = (currentPageIndex < events.Count);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            currentPageIndex = 0;
            printPreviewControl1.Document = printDocument;
            printPreviewControl1.Zoom = 1;
            printPreviewControl1.StartPage =0;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewControl1.StartPage++;
                
            }
            catch { 
            MessageBox.Show("This is the last page");
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewControl1.StartPage--;
                
            }
            catch
            {
                MessageBox.Show("This is the first page");
            }
        }
    }
}
