﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ASS1
{
    public partial class Report2 : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        private List<Dictionary<string, object>> events;
        private int currentPageIndex = 0;
        public Report2(DataModule dm, Mainform mnu)
        {
            InitializeComponent();

            LoadData();
            DM = dm;
            frmMenu = mnu;
        }

        private void Return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Print_Click(object sender, EventArgs e)
        {
            events = FetchEvents();  // Fetch all events
            currentPageIndex = 0;
            // printPreviewDialog.ShowDialog();(NOT Working and causes the next line not working)
            printDocument.Print();

        }

        private void LoadData()
        {
            // This should be replaced with actual data fetching logic
            events = FetchEvents();
        }
        private List<Dictionary<string, object>> FetchEvents()
        {
            // Simulated data fetching

            {
                DM = new DataModule();
                var events = new List<Dictionary<string, object>>();
                if (DM != null && DM.dtLoactions != null && DM.dtLoactions.Rows.Count > 0)
                {
                    for (int i = 0; i < DM.dtLoactions.Rows.Count; i++)
                    {
                        int LocationID = Convert.ToInt32(DM.dtLoactions.Rows[i]["LocationID"]);
                        var eventDict = new Dictionary<string, object>
                    {
                        {"LocationID", DM.dtLoactions.Rows[i]["LocationID"]},
                        {"LocationName", DM.dtLoactions.Rows[i]["LocationName"]},
                        {"Address", DM.GetLocationAddress(LocationID)},
                       
                    };
                        events.Add(eventDict);
                    }
                }
                return events;
            };
        }

        private List<Dictionary<string, object>> FetchRegistrationsForEvent(int locationId)
        {
            // Simulated data fetching for registrations
            var registrations = new List<Dictionary<string, object>>();

            foreach (DataRow row in DM.dtEvents.Select($"LocationID = {locationId}"))
            {
                int EventID = Convert.ToInt32(row["EventID"]);
                registrations.Add(new Dictionary<string, object>
        {
            {"EventID", row["EventID"]},
            {"EventName", row["EventName"]},
            {"EventDate", row["EventDate"]},
        });
            }

            return registrations;
        }

        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            // Settings for fonts and spacing
            Font headerFont = new Font("Arial", 12, FontStyle.Bold);
            Font regularFont = new Font("Arial", 10);
            float lineHeight = regularFont.GetHeight(e.Graphics);
            float headerLineHeight = headerFont.GetHeight(e.Graphics);

            int margin = 50;  // Set the margin from left/top
            int yPosition = margin;
            int xPosition = margin;

            // Loop through events starting from currentPageIndex
            while (currentPageIndex < events.Count)
            {
                // Fetch the location details
                Dictionary<string, object> location = events[currentPageIndex];
                int locationID = Convert.ToInt32(location["LocationID"]);
                string locationName = location["LocationName"].ToString();
                string locationAddress = location["Address"].ToString();

                // Print the Location header
                e.Graphics.DrawString($"Location ID: {locationID}", headerFont, Brushes.Black, xPosition, yPosition);
                yPosition += (int)headerLineHeight;
                e.Graphics.DrawString($"Location Name: {locationName}", regularFont, Brushes.Black, xPosition, yPosition);
                yPosition += (int)lineHeight;
                e.Graphics.DrawString($"Location Address: {locationAddress}", regularFont, Brushes.Black, xPosition, yPosition);
                yPosition += (int)lineHeight;

                // Fetch and print events related to the location
                List<Dictionary<string, object>> locationEvents = FetchRegistrationsForEvent(locationID);
                e.Graphics.DrawString("Events:", regularFont, Brushes.Black, xPosition, yPosition);
                yPosition += (int)lineHeight;

                foreach (var eventInfo in locationEvents)
                {
                    int eventID = Convert.ToInt32(eventInfo["EventID"]);
                    string eventName = eventInfo["EventName"].ToString();
                    DateTime eventDate = Convert.ToDateTime(eventInfo["EventDate"]);

                    // Print the Event details
                    e.Graphics.DrawString($"Event ID: {eventID}", regularFont, Brushes.Black, xPosition + 20, yPosition);
                    yPosition += (int)lineHeight;
                    e.Graphics.DrawString($"Event Name: {eventName}", regularFont, Brushes.Black, xPosition + 20, yPosition);
                    yPosition += (int)lineHeight;
                    e.Graphics.DrawString($"Event Date: {eventDate.ToString("yyyy/MM/dd")}", regularFont, Brushes.Black, xPosition + 20, yPosition);
                    yPosition += (int)lineHeight;

                    // Check if we are nearing the end of the page
                    if (yPosition + lineHeight > e.MarginBounds.Height)
                    {
                        // We need to continue on the next page
                        e.HasMorePages = true;
                        currentPageIndex++;  // Prepare for next event
                        return;
                    }
                }

                // Add some space after each location's events
                yPosition += (int)lineHeight * 2;

                currentPageIndex++;  // Move to the next location
            }

            // No more pages if all events have been printed
            e.HasMorePages = false;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            currentPageIndex = 0;
            printPreviewControl1.Document = printDocument;
            printPreviewControl1.Zoom = 1;
            printPreviewControl1.StartPage =0;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewControl1.StartPage++;

            }
            catch
            {
                MessageBox.Show("This is the last page");
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewControl1.StartPage--;

            }
            catch
            {
                MessageBox.Show("This is the first page");
            }
        }

        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            currentPageIndex = 0;
            printPreviewControl1.Document = printDocument;
            printPreviewControl1.Zoom = 1;
            printPreviewControl1.StartPage =0;
        }
    }
}
