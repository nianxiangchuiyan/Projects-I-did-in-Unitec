﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASS1
{
    public partial class Events : Form
    {
        private DataModule DM;
        private Mainform frmMenu;

        private CurrencyManager currencyManager;

        private void BindControls()
        {
            try
            {
                //Add bindings to text boxes
                txtEventID.DataBindings.Add("Text", DM.dsKai, "Event.EventID");
                txtEventName.DataBindings.Add("Text", DM.dsKai, "Event.EventName");
                txtEventDate.DataBindings.Add("Text", DM.dsKai, "Event.EventDate");
                txtEventLocation.DataBindings.Add("Text", DM.dsKai, "Event.LocationID");
                //disable text boxes
                txtEventDate.Enabled = false;
                txtEventName.Enabled = false;
                txtEventID.Enabled = false;
                txtEventLocation.Enabled = false;
                lstEvent.DataSource = DM.dsKai;
                lstEvent.DisplayMember = "Event.EventName";
                lstEvent.ValueMember = "Event.EventName";
                currencyManager = ((CurrencyManager)this.BindingContext[DM.dsKai, "Event"]);

                ArrayList LocationName = new ArrayList();
                //get location names to combo boxes
                LocationName.Add("");
                for (int i = 0; i < DM.dtLoactions.Rows.Count; i++)
                {
                    if (!LocationName.Contains(DM.dtLoactions.Rows[i][1]))
                        LocationName.Add(DM.dtLoactions.Rows[i][1]);
                }
                cbAddLocation.DataSource = LocationName;
                cbUpdateLocation.DataSource = LocationName;
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
        public Events(DataModule dm, Mainform mnu)
        {
            InitializeComponent();
            DM = dm;
            frmMenu = mnu;
            AddEventPanel.Location= new Point (200, 11);
            UpdateEventPanel.Location = new Point(200, 11);
            BindControls();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position > 0)
            {
                --currencyManager.Position;
            }
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position < currencyManager.Count - 1)
            {
                ++currencyManager.Position;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Disable buttons 

            btnUp.Enabled = false;
            btnDown.Enabled = false;
            btnAdd.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnReturn.Enabled = false;
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            lstEvent.Visible = false;
            AddEventPanel.Visible = true;


        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            //enable buttons 
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            lstEvent.Visible = true;
            AddEventPanel.Visible = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow newEventRow = DM.dtEvents.NewRow();
                //if event name is empty
                if (txtAddEventName.Text==""||txtAddEventName.Text.Trim().Length==0)
                {
                    MessageBox.Show("Event name can not be empty");
                }
                else
                {
                    newEventRow["EventName"] = txtAddEventName.Text;
                    if (cbAddLocation.Text == "")
                        newEventRow["LocationID"] = DBNull.Value;//set loaction to null when it is empty
                    else
                        newEventRow["LocationID"] = DM.GetLocationID(cbAddLocation.Text);
                    newEventRow["EventDate"] = dtpAddEventDate.Value;
                    //DM.ctnKai.Open();
                    //MessageBox.Show(DM.getFirstID(DM.dtEvents).ToString());
                    //newEventRow["EventID"] = DM.getFirstID(DM.dtEvents);
                    //DM.ctnKai.Close();
                    DM.dtEvents.Rows.Add(newEventRow);
                    DM.UpdateEvents();
                    MessageBox.Show("Event added successfully.");
                }
                //enable buttons 
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            lstEvent.Visible = true;
            AddEventPanel.Visible = false;
            }
            catch (Exception ex) { }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //diasble buttons
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            btnAdd.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnReturn.Enabled = false;
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            lstEvent.Visible = false;
            UpdateEventPanel.Visible = true;
            txtUpdateEventName.Text = DM.dtEvents.Rows[currencyManager.Position]["EventName"].ToString();
            
            if (DM.dtEvents.Rows[currencyManager.Position]["LocationID"] == DBNull.Value)
                cbUpdateLocation.Text = "";//show nothing when locationID is null
            else
                cbUpdateLocation.Text = DM.GetLocationName(Convert.ToInt32(DM.dtEvents.Rows[currencyManager.Position]["LocationID"]));//show location name
            dtpUpdateEventDate.Value = Convert.ToDateTime(DM.dtEvents.Rows[currencyManager.Position]["EventDate"]);//show date

        }

        private void btnUpdateCancle_Click(object sender, EventArgs e)
        {
            //enable buttons
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            lstEvent.Visible = true;
            UpdateEventPanel.Visible = false;
        }

        private void btnUpdateSave_Click(object sender, EventArgs e)
        {
            txtUpdateEventName.Text = DM.dtEvents.Rows[currencyManager.Position]["EventName"].ToString();
            
            dtpUpdateEventDate.Value = Convert.ToDateTime(DM.dtEvents.Rows[currencyManager.Position]["EventDate"]);
            try
            {
                DataRow newEventRow = DM.dtEvents.Rows[currencyManager.Position];
                if (txtUpdateEventName.Text==""||txtUpdateEventName.Text.Trim().Length==0)//if event name is empty
                    MessageBox.Show("Event name can not be empty");
                else
                {
                    newEventRow["EventName"] = txtUpdateEventName.Text;
                    if (cbUpdateLocation.Text == "")
                        newEventRow["LocationID"] = DBNull.Value;//set location to null when empty
                    else
                        newEventRow["LocationID"] = DM.GetLocationID(cbUpdateLocation.Text);
                    newEventRow["EventDate"] = dtpAddEventDate.Value;
                    DM.UpdateEvents();
                    MessageBox.Show("Event updated successfully.");
                }
                //enable buttons
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            lstEvent.Visible = true;
            UpdateEventPanel.Visible = false;
            }
            catch (Exception ex) { }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataRow row = DM.dtEvents.Rows[currencyManager.Position];
            //confirm deletion
            bool yes = MessageBox.Show("Are you sure you want to delete this event?", "Delete", MessageBoxButtons.YesNo) == DialogResult.Yes;
            if (yes && !DM.IsKaiRelation(Convert.ToInt32(row[0])))
            {

                row.Delete();
                DM.UpdateEvents();
                MessageBox.Show("“Event deleted successfully”");
            }
            else if (DM.IsKaiRelation(Convert.ToInt32(row[0])) && yes)
            {
                MessageBox.Show("You may only delete kai that have no event relation");
            }
        }
    }
}
