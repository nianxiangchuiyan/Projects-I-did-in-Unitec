﻿using ASS1;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASS1
{
    public partial class Kai : Form
    {
        private DataModule DM;
        private Mainform frmMenu;
        private CurrencyManager currencyManager;

        private void BindControls()
        {
            try
            {
            // Add a data bindings
                txtKaiID.DataBindings.Add("Text", DM.dsKai, "Kai.KaiID");
                txtKaiName.DataBindings.Add("Text", DM.dsKai, "Kai.KaiName");
                txtEvent.DataBindings.Add("Text", DM.dsKai, "Kai.EventID");
                txtPreparation.DataBindings.Add("Text", DM.dsKai, "Kai.PreparationRequired");
                
                numPreparationTime.DataBindings.Add("Value", DM.dsKai, "Kai.PreparationMinutes");
               
                numServingQuantity.DataBindings.Add("Value", DM.dsKai, "Kai.ServeQuantity");
                // Disable the text boxes.
                txtEvent.Enabled = false;
                numPreparationTime.Enabled = false;
                numServingQuantity.Enabled = false;
                txtKaiID.Enabled = false;
                txtKaiName.Enabled = false;
                txtPreparation.Enabled = false;
                lstKai.DataSource = DM.dsKai;
                lstKai.DisplayMember = "Kai.KaiName";
                lstKai.ValueMember = "Kai.KaiName";
                currencyManager = ((CurrencyManager)this.BindingContext[DM.dsKai, "Kai"]);
                
                

                // Create a new ArrayList
                ArrayList EventName = new ArrayList();
                EventName.Add("");
                for (int i = 0; i < DM.dtEvents.Rows.Count; i++)
                {
                    // If the current event name is not in the EventName list, add it
                    if(!EventName.Contains(DM.dtEvents.Rows[i][1]))
                    EventName.Add(DM.dtEvents.Rows[i][1]);
                }
                // Set the DataSource property of the cbUpdateEvent control to the EventName list
                cbUpdateEvent.DataSource = EventName;
                // Set the DataSource property of the cbAddEvent control to the EventName list
                cbAddEvent.DataSource = EventName;
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public Kai(DataModule dm, Mainform mnu)
        {
            InitializeComponent();
            DM = dm;
            frmMenu = mnu;
            BindControls();
            AddKaiPanel.Location= new Point(200, 10);
            UpdateKaiPanel.Location = new Point(200, 10);

        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position > 0)
            {
                --currencyManager.Position;
            }
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (currencyManager.Position < currencyManager.Count - 1)
            {
                ++currencyManager.Position;
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)

        {
            //disable the buttons and show add panel
            btnAdd.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnReturn.Enabled = false;
            btnUp.Enabled = false;
            btnDown.Enabled = false;
            /*
            txtKaiName.Enabled = true;
            txtEvent.Enabled = true;
            txtPreparation.Enabled = true;
            txtPreparationTime.Enabled = true;
            txtServingQuantity.Enabled = true;*/
            lstKai.Visible = false;
            numPreparationTime.Visible = false;
            numServingQuantity.Visible = false;
            AddKaiPanel.Visible = true;

        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            //enable the buttons and hide add panel
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            lstKai.Visible = true;
            numPreparationTime.Visible = true;
            numServingQuantity.Visible = true;
            AddKaiPanel.Visible = false;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataRow newKaiRow = DM.dtKai.NewRow();
            //Check if the Kai name is empty
            if ((txtAddKaiName.Text == ""))
            {
                //If it is, show an error message
                MessageBox.Show("You must type in a Kai name", "Error");
            }
            else
            {
                //If not, create a new row in the dtKai table
                Boolean error = false;
                try
                {
                    error = false;
                    newKaiRow["KaiName"] = txtAddKaiName.Text;
                    
                    //Check if the Event is empty
                    if (cbAddEvent.Text!=null||cbAddEvent.Text=="")
                    {
                        //If it is, set the EventID to DBNull
                        newKaiRow["EventID"]=DBNull.Value;
                    }
                    else
                    {
                        //If not, get the EventID from the dtEvents table
                        String eventName = cbAddEvent.Text;
                        int ID = Convert.ToInt32(DM.dtEvents.Rows.Find(cbAddEvent.Text)["EventID"]);
                        newKaiRow["EventID"] = ID;
                    }
                    
                    //Set the values
                    newKaiRow["PreparationRequired"] = cbPreparation.Checked;
                  
                    newKaiRow["PreparationMinutes"] = numAddPreparationTime.Text;
                  
                    newKaiRow["ServeQuantity"] = numAddServingQuantity.Text;
                    //Tried use the following code to set the KaiID to the next available number, also saves the new row to the database
                  /*  DM.ctnKai.Open();
                    for (int i = 1; ; i++)
                    {
                        Boolean found = false;
                        try
                        {
                            
                            newKaiRow["KaiID"] = i;*/
                            DM.dtKai.Rows.Add(newKaiRow);
                            //Update the dtKai table
                            DM.UpdateKai();
                       /*     
                        }
                        catch (Exception)
                        {
                            found = true;
                        }
                        if (!found)
                        {

                            break;
                        }
                    }*/
                    



                }
                catch (FormatException ex)
                {
                    MessageBox.Show("Please enter a number for EventID", "Error");

                    error = true;
                }
                catch (System.Data.OleDb.OleDbException ex)
                {
                    MessageBox.Show("Please enter a vaild number for EventID (You current input is out of range, check what is the correct ID)", "Error");
                    error = true;
                    newKaiRow.Delete();
                }
                finally
                {
                    // Add the new row to the Kai DataTable and update the database

                    // Hide the panel and show success message
                    if (!error)
                    {
                        AddKaiPanel.Visible = false;
                        lstKai.Visible = true;
                        btnUp.Enabled = true;
                        btnDown.Enabled = true;
                        btnReturn.Enabled = true;
                        btnUpdate.Enabled = true;
                        btnDelete.Enabled = true;
                        btnAdd.Enabled = true;
                        numPreparationTime.Visible = true;
                        numServingQuantity.Visible = true;

                        
                        DM.UpdateKai();
                        MessageBox.Show("Kai added successfully", "Success");
                    }
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Enable the update panel and disable other buttons
            btnAdd.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnReturn.Enabled = false;
            btnUp.Enabled = false;
            btnDown.Enabled = false;

           /* txtKaiName.Enabled = true;
            txtEvent.Enabled = true;
            txtPreparation.Enabled = true;
            txtPreparationTime.Enabled = true;
            txtServingQuantity.Enabled = true;*/
            lstKai.Visible = false;
            numPreparationTime.Visible = false;
            numServingQuantity.Visible = false;
            UpdateKaiPanel.Visible = true;
            DataRow updateKaiRow = DM.dtKai.Rows[currencyManager.Position];
            //Update the textboxes with the values from the selected row
            txtUpdateKaiID.Text = updateKaiRow["KaiID"].ToString();
            txtUpdateKaiName.Text = updateKaiRow["KaiName"].ToString();
            if (updateKaiRow["EventID"]!= DBNull.Value)
            cbUpdateEvent.Text = DM.GetEventName(Convert.ToInt32(updateKaiRow["EventID"]));
            
            cbUpdatePreparation.Checked = Convert.ToBoolean(updateKaiRow["PreparationRequired"]);
            numUpdatePreparationTime.Text = updateKaiRow["PreparationMinutes"].ToString();
            numUpdateServingQuantity.Text = updateKaiRow["ServeQuantity"].ToString();
        }

        private void btnUpdateCancel_Click(object sender, EventArgs e)
        {
            // Hide the panel and enable the list and buttons
            btnAdd.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            btnReturn.Enabled = true;
            btnUp.Enabled = true;
            btnDown.Enabled = true;
            lstKai.Visible = true;
            numPreparationTime.Visible = true;
            numServingQuantity.Visible = true;
            UpdateKaiPanel.Visible = false;
        }
        private void UpdateKai(DataRow updateKaiRow)
        {
            // Update the row with the new values
            updateKaiRow["KaiName"] = txtUpdateKaiName.Text;
            try
            {

                if (updateKaiRow["EventID"]!=null)
                    updateKaiRow["EventID"] = DM.GetEventID(cbUpdateEvent.Text);
                
            }
            catch (InvalidConstraintException) {
            
                    updateKaiRow["EventID"] = DBNull.Value;
            }
            updateKaiRow["PreparationRequired"] = cbUpdatePreparation.Checked;
            updateKaiRow["PreparationMinutes"] = Convert.ToInt32(numUpdatePreparationTime.Text);
            updateKaiRow["ServeQuantity"] = Convert.ToInt32(numUpdateServingQuantity.Text);
            currencyManager.EndCurrentEdit();
            DM.UpdateKai();


        }

        private void btnUpdateSave_Click(object sender, EventArgs e)
        {
            // Update the row with the new values
            DataRow updateKaiRow = DM.dtKai.Rows[currencyManager.Position];
            if (txtUpdateKaiName.Text == "")
            {
                MessageBox.Show("Kai name can not be empty");
            }
            else
            {
                UpdateKai(DM.dtKai.Rows[currencyManager.Position]);

                btnAdd.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
                btnReturn.Enabled = true;
                btnUp.Enabled = true;
                btnDown.Enabled = true;
                lstKai.Visible = true;
                numPreparationTime.Visible = true;
                numServingQuantity.Visible = true;
                UpdateKaiPanel.Visible = false;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Delete the selected row
            DataRow deleteKaiRow = DM.dtKai.Rows[currencyManager.Position];
            Boolean yes =MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo) == DialogResult.Yes;
            //  if the kai has no event relation
            if (yes && deleteKaiRow[1]==DBNull.Value)
            {
                // Delete the row
                deleteKaiRow.Delete();
                DM.UpdateKai();
                MessageBox.Show("“Kai deleted successfully”");
            }
            //  if the kai has any event relation
            else if (deleteKaiRow[1]!=DBNull.Value && yes)
            {
                MessageBox.Show("You may only delete kai that have no event relation");
            }

        }

        private void txtEvent_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Get the event name from the database
                int EventID = Convert.ToInt32(txtEvent.Text);
                txtEvent.Text = DM.GetEventName(EventID);
            }
            catch { }
        }
       




    }
}

